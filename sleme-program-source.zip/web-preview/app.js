const DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
const DAY_NAMES = { monday: "Понедельник", tuesday: "Вторник", wednesday: "Среда", thursday: "Четверг", friday: "Пятница", saturday: "Суббота" };
const DAY_SHORT = { monday: "ПН", tuesday: "ВТ", wednesday: "СР", thursday: "ЧТ", friday: "ПТ", saturday: "СБ" };
const ADMIN_UID = "3hZ5bKEPYmSQ4TaH783ZJGiNyTv2";
const OWNER_EMAIL = "anonimysskamer@gmail.com";
const DEFAULT_BELLS = ["08:30", "09:20", "10:20", "11:20", "12:10", "13:00", "13:50", "14:40", "15:20", "16:10"];
const DEFAULT_SCHEDULES = {
  monday: ["Русский", "Математика", "История", "Физика", "Литература", "Химия", "География", "Иностранный", "Технология", "Физкультура"],
  tuesday: ["Математика", "Русский", "Биология", "Обществознание", "Информатика", "География", "Музыка", "ОБЖ", "Труд", "Физкультура"],
  wednesday: ["Алгебра", "Литература", "Химия", "История", "Физика", "Русский", "География", "Черчение", "Биология", "Физкультура"],
  thursday: ["Математика", "Русский", "Английский", "Информатика", "Физика", "География", "История", "Химия", "ОБЖ", "Физкультура"],
  friday: ["Русский", "Алгебра", "География", "Литература", "История", "Английский", "Физкультура", "Музыка", "Технология", "Гимнастика"],
  saturday: Array(10).fill("")
};
const DEFAULT_GROUPS = ["60ТО", "1ИСО", "61ТО"];
const RESERVED_GROUP_KEYS = new Set(["__proto__", "constructor", "prototype"]);
const PUBLIC_TABS = new Set(["today", "countdown", "settings"]);
const ADMIN_TABS = new Set(["schedule", "bells"]);
const PUBLIC_ONLY_TABS = new Set(["week"]);
const content = document.querySelector("#content");
const appShell = document.querySelector(".app-shell");
const cloudIndicator = document.querySelector("#cloud-indicator");
const cloudLabel = document.querySelector("#cloud-label");
const toastNode = document.querySelector("#toast");
const groupPicker = document.querySelector("#group-picker");
const groupSwitcher = document.querySelector("#group-switcher");
const currentGroupLabel = document.querySelector("#current-group");

let state = readLocalState();
let activeTab = "today";
let selectedDay = weekdayKey(new Date()) || "monday";
let auth = null;
let firestore = null;
let firebaseApi = null;
let firebaseAppSdk = null;
let firebaseAuthSdk = null;
let firebaseConfig = null;
let currentUser = null;
let cloudUnsubscribe = null;
let toastTimer = 0;
let displayedToday = "";

function readLocalState() {
  let saved = {};
  try {
    saved = JSON.parse(localStorage.getItem("sleme.web.state") || "{}");
  } catch (error) {
    console.error("Не удалось прочитать сохранённое расписание", error);
  }
  const sanitizedSaved = { ...saved };
  delete sanitizedSaved.backgroundImage;
  const groupSchedules = {};
  const groupRooms = {};
  const groupStudyDays = {};
  const storedGroups = sanitizedSaved.groupSchedules && typeof sanitizedSaved.groupSchedules === "object"
    ? sanitizedSaved.groupSchedules
    : {};
  const storedRooms = sanitizedSaved.groupRooms && typeof sanitizedSaved.groupRooms === "object"
    ? sanitizedSaved.groupRooms
    : {};
  const savedGroupNames = Array.isArray(sanitizedSaved.groups)
    ? sanitizedSaved.groups.filter(group => isValidGroupName(group))
    : [...DEFAULT_GROUPS, ...Object.keys(storedGroups).filter(group => !DEFAULT_GROUPS.includes(group))];
  const groups = [...new Set(savedGroupNames)];
  for (const group of groups) {
    groupSchedules[group] = normalizeSchedule(
      storedGroups[group] || (group === "60ТО" ? saved.schedules : null),
      group === "60ТО" ? DEFAULT_SCHEDULES : emptySchedule()
    );
    groupRooms[group] = normalizeRooms(
      storedRooms[group] || (group === saved.selectedGroup ? saved.rooms : null)
    );
    groupStudyDays[group] = sanitizedSaved.groupStudyDays?.[group] === 6 ? 6 : 5;
  }
  if (!Array.isArray(sanitizedSaved.groups)) {
    for (const [group, schedule] of Object.entries(storedGroups)) {
      if (!isValidGroupName(group)) continue;
      if (!groups.includes(group)) groups.push(group);
      groupSchedules[group] = normalizeSchedule(schedule, emptySchedule());
      groupRooms[group] = normalizeRooms(storedRooms[group]);
      groupStudyDays[group] = sanitizedSaved.groupStudyDays?.[group] === 6 ? 6 : 5;
    }
  }
  const selectedGroup = groups.includes(sanitizedSaved.selectedGroup) ? sanitizedSaved.selectedGroup : groups[0] || "";
  const schedules = groupSchedules[selectedGroup] || emptySchedule();
  const bells = Array.isArray(sanitizedSaved.bells)
    ? [...sanitizedSaved.bells.slice(0, 10), ...DEFAULT_BELLS.slice(sanitizedSaved.bells.length, 10)].slice(0, 10)
      .map((value, index) => normalizeTime(value) || DEFAULT_BELLS[index])
    : [...DEFAULT_BELLS];
  const theme = ["violet", "ocean", "sunset"].includes(sanitizedSaved.theme) ? sanitizedSaved.theme : "violet";
  return {
    bells,
    schedules,
    groups,
    groupSchedules,
    rooms: groupRooms[selectedGroup] || emptyRooms(),
    groupRooms,
    groupStudyDays,
    selectedGroup,
    theme,
    admins: Array.isArray(sanitizedSaved.admins)
      ? sanitizedSaved.admins.filter(admin => admin && typeof admin.uid === "string").map(admin => ({
        uid: admin.uid,
        email: typeof admin.email === "string" ? admin.email : ""
      }))
      : [],
    adminUids: Array.isArray(sanitizedSaved.adminUids)
      ? sanitizedSaved.adminUids.filter(uid => typeof uid === "string")
      : []
  };
}

function persist() {
  if (state.selectedGroup && state.groupSchedules[state.selectedGroup]) {
    state.groupSchedules[state.selectedGroup] = cloneSchedule(state.schedules);
    state.groupRooms[state.selectedGroup] = cloneSchedule(state.rooms);
  }
  const stateToStore = { ...state };
  delete stateToStore.backgroundImage;
  localStorage.setItem("sleme.web.state", JSON.stringify(stateToStore));
}

function emptySchedule() {
  return Object.fromEntries(DAYS.map(day => [day, Array(10).fill("")]));
}

function emptyRooms() {
  return emptySchedule();
}

function normalizeRooms(source) {
  return Object.fromEntries(DAYS.map(day => {
    const values = source?.[day];
    return [day, Array.isArray(values)
      ? [...values.slice(0, 10), ...Array(10).fill("")].slice(0, 10).map(value => String(value))
      : Array(10).fill("")];
  }));
}

function normalizeSchedule(source, fallback) {
  return Object.fromEntries(DAYS.map(day => {
    const values = source?.[day];
    return [day, Array.isArray(values)
      ? [...values.slice(0, 10), ...Array(10).fill("")].slice(0, 10).map(value => String(value))
      : [...fallback[day]]];
  }));
}

function cloneSchedule(schedule) {
  return Object.fromEntries(DAYS.map(day => [day, [...schedule[day]]]));
}

function isValidGroupName(value) {
  if (typeof value !== "string") return false;
  const normalized = value.trim();
  if (!normalized || normalized !== value || !/^[\p{L}\p{N} _-]{1,24}$/u.test(normalized)) return false;
  return !RESERVED_GROUP_KEYS.has(normalized.toLowerCase());
}

function groupNames() {
  return state.groups;
}

function isOwner() {
  return currentUser?.uid === ADMIN_UID || (
    Boolean(currentUser?.emailVerified) &&
    currentUser?.email?.toLowerCase() === OWNER_EMAIL
  );
}

function isAdmin() {
  return isOwner() || (Boolean(currentUser?.uid && state.adminUids.includes(currentUser.uid)) && Boolean(currentUser?.emailVerified));
}

function setTheme(theme) {
  state.theme = theme;
  document.documentElement.dataset.theme = theme;
  persist();
}

function setCloudStatus(message, kind = "") {
  cloudLabel.textContent = message;
  cloudIndicator.classList.toggle("online", kind === "online");
  cloudIndicator.classList.toggle("error", kind === "error");
}

function showToast(message) {
  toastNode.textContent = message;
  toastNode.classList.add("show");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toastNode.classList.remove("show"), 2800);
}

function renderGroupPicker() {
  const admin = isAdmin();
  const owner = isOwner();
  const selectedDays = document.querySelector('input[name="new-group-days"]:checked')?.value || "5";
  groupPicker.innerHTML = `
    <div class="group-picker-backdrop"></div>
    <section class="group-picker-card" role="dialog" aria-modal="true" aria-labelledby="group-picker-title">
      <div class="group-picker-heading">
        <div><p class="eyebrow">sleme program</p><h2 id="group-picker-title">Выберите группу</h2><p class="subtitle">Покажем расписание выбранной группы</p></div>
        ${state.groupChosen ? '<button class="group-picker-close" type="button" data-group-close aria-label="Закрыть">×</button>' : ""}
      </div>
      <div class="group-options">
        ${groupNames().map(group => `<div class="group-option-row">
          <button class="group-option ${group === state.selectedGroup ? "active" : ""}" type="button" data-group="${escapeHtml(group)}"><strong>${escapeHtml(group)}</strong><span>${state.groupStudyDays[group] === 6 ? "6 учебных дней" : "5 учебных дней"}</span></button>
          ${owner ? `<button class="group-delete-button" type="button" data-delete-group="${escapeHtml(group)}" aria-label="Удалить группу ${escapeHtml(group)}" title="Удалить группу">×</button>` : ""}
        </div>`).join("")}
      </div>
      ${owner ? `<form class="add-group-form" id="add-group-form">
        <label for="new-group-name">Добавить группу</label>
        <div class="add-group-controls"><input class="field" id="new-group-name" maxlength="24" placeholder="Например, 62ТО" autocomplete="off"><button class="button primary" type="submit">Добавить</button></div>
        <fieldset class="study-days-picker">
          <legend>Учебных дней в неделю</legend>
          <label class="study-days-option ${selectedDays === "5" ? "active" : ""}"><input type="radio" name="new-group-days" value="5" ${selectedDays === "5" ? "checked" : ""}><span><strong>5 дней</strong><small>Понедельник — пятница</small></span><span class="study-days-check">✓</span></label>
          <label class="study-days-option ${selectedDays === "6" ? "active" : ""}"><input type="radio" name="new-group-days" value="6" ${selectedDays === "6" ? "checked" : ""}><span><strong>6 дней</strong><small>Понедельник — суббота</small></span><span class="study-days-check">✓</span></label>
        </fieldset>
        <p class="settings-status" id="group-picker-status" aria-live="polite"></p>
      </form>` : ""}
      ${!admin ? '<p class="group-picker-note">Чтобы создать или изменить расписание групп, войдите как администратор в настройках.</p>' : ""}
    </section>`;
  groupPicker.hidden = false;
}

function closeGroupPicker() {
  if (!state.groupChosen) return;
  groupPicker.hidden = true;
}

function selectGroup(group) {
  if (!groupNames().includes(group)) return;
  if (state.selectedGroup && state.groupSchedules[state.selectedGroup]) {
    state.groupSchedules[state.selectedGroup] = cloneSchedule(state.schedules);
    state.groupRooms[state.selectedGroup] = cloneSchedule(state.rooms);
  }
  state.selectedGroup = group;
  state.schedules = cloneSchedule(state.groupSchedules[group] || emptySchedule());
  state.rooms = cloneSchedule(state.groupRooms[group] || emptyRooms());
  state.groupChosen = true;
  persist();
  closeGroupPicker();
  render();
}

function addGroup(groupName) {
  if (!isOwner()) return;
  const name = groupName.trim().toLocaleUpperCase("ru-RU");
  const status = document.querySelector("#group-picker-status");
  if (!isValidGroupName(name)) {
    setSettingsMessage(status, "Используйте 1–24 буквы или цифры, пробел, дефис или подчёркивание.", "error");
    return;
  }
  if (groupNames().some(group => group.toLocaleUpperCase("ru-RU") === name)) {
    setSettingsMessage(status, `Группа «${name}» уже существует.`, "error");
    return;
  }
  state.groupSchedules[name] = emptySchedule();
  state.groupRooms[name] = emptyRooms();
  state.groups.push(name);
  state.groupStudyDays[name] = Number(document.querySelector('input[name="new-group-days"]:checked')?.value) === 6 ? 6 : 5;
  const defaultDaysOption = groupPicker.querySelector('input[name="new-group-days"][value="5"]');
  if (defaultDaysOption) defaultDaysOption.checked = true;
  groupPicker.querySelectorAll(".study-days-option").forEach(option => {
    option.classList.toggle("active", option.contains(defaultDaysOption));
  });
  persist();
  selectGroup(name);
  showToast(`Группа «${name}» добавлена`);
}

function deleteGroup(groupName) {
  if (!isOwner() || !state.groups.includes(groupName)) return;
  if (state.groups.length <= 1) {
    showToast("Нельзя удалить последнюю группу");
    return;
  }
  if (!window.confirm(`Удалить группу «${groupName}» и её расписание?`)) return;

  state.groups = state.groups.filter(group => group !== groupName);
  delete state.groupSchedules[groupName];
  delete state.groupRooms[groupName];
  delete state.groupStudyDays[groupName];
  if (state.selectedGroup === groupName) {
    state.selectedGroup = state.groups[0];
    state.schedules = cloneSchedule(state.groupSchedules[state.selectedGroup]);
    state.rooms = cloneSchedule(state.groupRooms[state.selectedGroup] || emptyRooms());
  }
  persist();
  render();
  showToast(`Группа «${groupName}» удалена`);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

function weekdayKey(date) {
  const index = date.getDay();
  return index >= 1 && index <= 6 ? DAYS[index - 1] : null;
}

function isStudyDay(date, group = state.selectedGroup) {
  const day = weekdayKey(date);
  const studyDays = state.groupStudyDays[group] === 6 ? 6 : 5;
  return day !== null && DAYS.indexOf(day) < studyDays;
}

function currentDateLabel(date = new Date()) {
  return new Intl.DateTimeFormat("ru-RU", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(date);
}

function normalizeTime(value) {
  const match = /^(\d{1,2}):([0-5]\d)$/.exec(String(value));
  if (!match || Number(match[1]) > 23) return "";
  return `${String(Number(match[1])).padStart(2, "0")}:${match[2]}`;
}

function timeToDate(date, time) {
  const match = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(normalizeTime(time));
  if (!match) return null;
  const target = new Date(date);
  target.setHours(Number(match[1]), Number(match[2]), 0, 0);
  return target;
}

function lessonsForDay(day, date) {
  return state.schedules[day]
    .map((name, index) => ({ name: name.trim(), index, time: state.bells[index], start: timeToDate(date, state.bells[index]) }))
    .filter(lesson => lesson.name && lesson.start)
    .sort((first, second) => first.start - second.start);
}

function lessonEnd(lesson, next) {
  const estimatedEnd = new Date(lesson.start.getTime() + 45 * 60 * 1000);
  return next && next.start < estimatedEnd ? next.start : estimatedEnd;
}

function nextSchoolLesson(now, options = {}) {
  const startOffset = options.includeToday ? 0 : 1;
  const maxOffsets = 12;

  for (let offset = startOffset; offset <= maxOffsets; offset += 1) {
    const date = new Date(now);
    date.setDate(date.getDate() + offset);
    date.setHours(0, 0, 0, 0);
    if (!isStudyDay(date)) continue;

    const day = weekdayKey(date);
    const lessons = lessonsForDay(day, date);
    if (!lessons.length) continue;

    const lesson = lessons[0];
    return {
      day,
      index: lesson.index,
      date: lesson.start,
      start: lesson.start,
      name: lesson.name,
      time: lesson.time,
      phase: options.weekend ? "weekend" : "nextday"
    };
  }
  return null;
}

function nextLesson(now = new Date()) {
  const day = weekdayKey(now);
  if (!isStudyDay(now)) {
    return nextSchoolLesson(now, { weekend: true });
  }

  const lessons = lessonsForDay(day, now);
  const nextIndex = lessons.findIndex(lesson => lesson.start > now);
  if (nextIndex === 0) {
    const lesson = lessons[0];
    return { day, index: lesson.index, date: lesson.start, start: lesson.start, name: lesson.name, time: lesson.time, phase: "before" };
  }
  if (nextIndex > 0) {
    const previous = lessons[nextIndex - 1];
    const upcoming = lessons[nextIndex];
    const end = lessonEnd(previous, upcoming);
    if (now < end) {
      return { day, index: previous.index, date: end, start: previous.start, name: previous.name, nextName: upcoming.name, time: upcoming.time, phase: "lesson" };
    }
    return { day, index: upcoming.index, date: upcoming.start, start: upcoming.start, name: upcoming.name, previousName: previous.name, time: upcoming.time, phase: "break" };
  }
  if (lessons.length) {
    const previous = lessons[lessons.length - 1];
    const end = lessonEnd(previous, null);
    if (now < end) {
      return { day, index: previous.index, date: end, start: previous.start, name: previous.name, time: previous.time, phase: "lesson" };
    }
  }
  return nextSchoolLesson(now);
}

function durationLabel(milliseconds) {
  const total = Math.max(0, Math.floor(milliseconds / 1000));
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);

  if (days > 0) {
    return `${days}д ${hours}ч ${minutes}м`;
  }
  if (hours > 0) {
    return `${hours}ч ${minutes.toString().padStart(2, "0")}м`;
  }
  return `${minutes}м`;
}

function renderToday() {
  const now = new Date();
  const key = weekdayKey(now);
  displayedToday = now.toDateString();
  if (!isStudyDay(now)) {
    const next = nextLesson(now);
    return `
      <div class="page-heading">
        <div><p class="eyebrow">sleme program / ${escapeHtml(state.selectedGroup)}</p><h2>Хорошего отдыха!</h2><p class="subtitle">${escapeHtml(currentDateLabel(now))} · ${escapeHtml(state.selectedGroup)}</p></div>
        <span class="date-chip">${escapeHtml(currentDateLabel(now))}</span>
      </div>
      <section class="weekend-card">
        <span class="weekend-illustration" aria-hidden="true">☀</span>
        <span class="weekend-kicker">ВРЕМЯ ПЕРЕЗАРЯДИТЬСЯ</span>
        <h2>Сегодня выходной</h2>
        <p>Наберись сил — занятия продолжатся в понедельник.</p>
        ${next ? `<div class="weekend-next"><span>Следующее занятие</span><strong>${escapeHtml(DAY_NAMES[next.day])} · ${escapeHtml(next.time)}</strong><small>${escapeHtml(next.name)}</small></div>` : ""}
        <button class="button weekend-button" data-tab="week" type="button">Посмотреть расписание недели <span>→</span></button>
      </section>`;
  }
  const liveLesson = nextLesson(now);
  const soonIndex = liveLesson && ["before", "lesson", "break"].includes(liveLesson.phase) ? liveLesson.index : -1;
  const todayLessons = state.schedules[key];
  const lessons = todayLessons.map((subject, index) => `
    <div class="lesson-row ${index === soonIndex ? "next" : ""}">
      <span class="lesson-index">${String(index + 1).padStart(2, "0")}</span>
      <span class="lesson-subject">${escapeHtml(subject || "—")}${state.rooms[key][index].trim() ? `<small class="lesson-room">Кабинет ${escapeHtml(state.rooms[key][index].trim())}</small>` : ""}</span>
      <span class="lesson-meta">${index === soonIndex ? '<span class="now-label">ДАЛЕЕ</span>' : ""}${escapeHtml(state.bells[index] || "—")}</span>
    </div>`).join("");
  return `
    <div class="page-heading">
      <div><p class="eyebrow">sleme program / ${escapeHtml(state.selectedGroup)}</p><h2>Расписание на сегодня</h2><p class="subtitle">${escapeHtml(DAY_NAMES[key])} · ${escapeHtml(state.selectedGroup)}</p></div>
      <span class="date-chip">${escapeHtml(currentDateLabel(now))}</span>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><span class="stat-icon">▦</span><span><small>Уроков сегодня</small><strong>${todayLessons.filter(Boolean).length}</strong></span></div>
      <div class="stat-card"><span class="stat-icon">◴</span><span><small>Следующий урок</small><strong>${soonIndex >= 0 ? escapeHtml(state.bells[soonIndex]) : "—"}</strong></span></div>
      <div class="stat-card"><span class="stat-icon">♧</span><span><small>Учебная неделя</small><strong>${state.groupStudyDays[state.selectedGroup]} дней</strong></span></div>
    </div>
    <section class="card">
      <div class="card-heading"><div><h2>План дня</h2><p>Предметы и время начала занятий</p></div><span class="tag">${escapeHtml(DAY_SHORT[key])}</span></div>
      <div class="lesson-list">${todayLessons.some(Boolean) ? lessons : '<div class="empty-state">Расписание на сегодня пока не заполнено</div>'}</div>
    </section>`;
}

function renderWeekSchedule() {
  const today = isStudyDay(new Date()) ? weekdayKey(new Date()) : "";
  const studyDays = state.groupStudyDays[state.selectedGroup] === 6 ? 6 : 5;
  const shownDays = DAYS.slice(0, studyDays);
  const weekLessons = shownDays.reduce((total, day) => total + state.schedules[day].filter(subject => subject.trim()).length, 0);
  const dayCards = shownDays.map(day => {
    const lessons = state.schedules[day]
      .map((subject, index) => ({ subject: subject.trim(), index, room: state.rooms[day][index].trim() }))
      .filter(lesson => lesson.subject);
    const rows = lessons.length
      ? lessons.map(({ subject, index, room }) => `
        <div class="week-lesson">
          <span class="week-lesson-number">${String(index + 1).padStart(2, "0")}</span>
          <span class="week-lesson-subject">${escapeHtml(subject)}${room ? `<small class="week-lesson-room">Кабинет ${escapeHtml(room)}</small>` : ""}</span>
          <span class="week-lesson-time">${escapeHtml(state.bells[index] || "—")}</span>
        </div>`).join("")
      : '<div class="week-empty-day"><span class="week-empty-icon">✦</span><span>Занятий пока нет</span></div>';
    return `
      <section class="week-day-card ${day === today ? "is-today" : ""}" id="week-day-${day}">
        <div class="week-day-heading">
          <span class="week-day-monogram">${escapeHtml(DAY_SHORT[day])}</span>
          <div class="week-day-title"><h2>${escapeHtml(DAY_NAMES[day])}</h2><p>${lessons.length ? `${lessons.length} ${lessons.length === 1 ? "урок" : lessons.length < 5 ? "урока" : "уроков"}` : "Свободный день"}</p></div>
          ${day === today ? '<span class="week-today-badge">СЕГОДНЯ</span>' : ""}
        </div>
        <div class="week-lesson-list">${rows}</div>
      </section>`;
  }).join("");
  return `
    <div class="week-page">
      <section class="week-hero">
        <div class="week-hero-top"><span class="week-eyebrow"><span class="week-live-dot"></span> ТВОЯ УЧЕБНАЯ НЕДЕЛЯ</span><span class="week-hero-mark" aria-hidden="true">✳</span></div>
        <h1>Вся неделя<br><span>в одном месте</span></h1>
        <p class="week-hero-copy">Полный план занятий группы <strong>${escapeHtml(state.selectedGroup)}</strong> — листай дни и смотри, что впереди.</p>
        <div class="week-hero-stats"><span class="week-stat-icon">▤</span><strong>${weekLessons}</strong><span>уроков<br>за неделю</span><span class="week-stat-divider"></span><strong>${String(studyDays).padStart(2, "0")}</strong><span>учебных<br>дней</span></div>
      </section>
      <nav class="week-day-nav ${studyDays === 6 ? "days-6" : ""}" aria-label="Перейти к дню недели">
        ${shownDays.map((day, index) => `<button class="week-day-link ${day === today ? "is-today" : ""}" type="button" data-week-day="${day}" aria-label="Перейти к расписанию: ${DAY_NAMES[day]}"><span>${escapeHtml(DAY_SHORT[day])}</span><small>${String(index + 1).padStart(2, "0")}</small></button>`).join("")}
      </nav>
      <div class="week-section-heading"><div><span class="week-section-kicker">ПОНЕДЕЛЬНИК — ${studyDays === 6 ? "СУББОТА" : "ПЯТНИЦА"}</span><h2>План занятий</h2></div><span class="week-readonly"><span>◉</span> Только просмотр</span></div>
      <div class="week-day-list">${dayCards}</div>
    </div>`;
}

function countdownPresentation(next, now) {
  if (!next) return { phase: "empty", title: "Нет занятий", name: "Расписание занятий не найдено", caption: "Проверьте расписание выбранной группы.", context: "", duration: "—" };
  const titles = {
    before: "До начала урока",
    lesson: "До конца урока",
    break: "До следующего урока",
    weekend: "До учебного дня",
    nextday: "До следующего учебного дня"
  };
  const captions = {
    before: `Начало ${next.time}`,
    lesson: `Урок закончится примерно в ${next.date.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}`,
    break: `Перемена · следующий урок в ${next.time}`,
    weekend: `Следующий учебный день · ${next.time}`,
    nextday: `Следующий учебный день · ${next.time}`
  };
  return {
    phase: next.phase,
    title: titles[next.phase] || titles.nextday,
    name: `${next.name} · ${DAY_NAMES[next.day]}`,
    caption: `${captions[next.phase] || ""} · ${currentDateLabel(next.start || next.date)}`,
    context: next.phase === "weekend" ? "Сегодня выходной — отдыхай, мы напомним о следующем учебном дне." : next.phase === "lesson" ? `Сейчас идёт урок «${next.name}»` : next.phase === "break" ? `Перемена после урока «${next.previousName}»` : "",
    duration: durationLabel(next.date - now)
  };
}

function countdownLessons(next) {
  if (!next) return [];
  const date = new Date(next.start || next.date);
  const lessons = lessonsForDay(next.day, date);
  const startIndex = Math.max(0, lessons.findIndex(lesson => lesson.index >= next.index));
  return lessons.slice(startIndex, startIndex + 3);
}

function renderCountdownState(now = new Date()) {
  const next = nextLesson(now);
  const presentation = countdownPresentation(next, now);
  const card = content.querySelector(".countdown-card");
  if (!card) return;
  card.dataset.phase = presentation.phase;
  card.querySelector(".countdown-phase").textContent = presentation.title;
  card.querySelector(".countdown-name").textContent = presentation.name;
  card.querySelector(".countdown-clock").textContent = presentation.duration;
  card.querySelector(".countdown-caption").textContent = presentation.caption;
  card.querySelector(".countdown-context").textContent = presentation.context;
  card.querySelector(".countdown-context").hidden = !presentation.context;
  const list = content.querySelector("#countdown-lessons");
  const lessons = countdownLessons(next);
  const lessonMarkup = lessons.length
    ? lessons.map(lesson => `<div class="mini-lesson ${lesson.index === next.index ? "upcoming-current" : ""}"><span>${escapeHtml(lesson.name)}${state.rooms[next.day][lesson.index].trim() ? `<small class="lesson-room">Кабинет ${escapeHtml(state.rooms[next.day][lesson.index].trim())}</small>` : ""}</span><span>${escapeHtml(lesson.time)}</span></div>`).join("")
    : '<div class="empty-state">Нет ближайших уроков</div>';
  if (list.dataset.content !== lessonMarkup) {
    list.innerHTML = lessonMarkup;
    list.dataset.content = lessonMarkup;
  }
  const section = content.querySelector("#countdown-day");
  if (section) section.textContent = next ? DAY_NAMES[next.day] : "Расписание";
}

function renderCountdown() {
  return `
    <div class="page-heading"><div><p class="eyebrow">таймер в реальном времени</p><h1>Таймер занятий</h1><p class="subtitle">${escapeHtml(state.selectedGroup)} · уроки, перемены и выходные</p></div></div>
    <div class="countdown-layout">
      <section class="card countdown-card"><span class="hourglass">◴</span><span class="countdown-phase"></span><p class="countdown-name"></p><div class="countdown-clock"></div><p class="countdown-caption"></p><p class="countdown-context" hidden></p></section>
      <section class="card"><div class="card-heading"><div><h2>Ближайшие уроки</h2><p id="countdown-day">Расписание</p></div></div>
        <div class="mini-list" id="countdown-lessons"></div>
      </section>
    </div>`;
}

function renderSchedule() {
  const studyDays = state.groupStudyDays[state.selectedGroup] === 6 ? 6 : 5;
  const shownDays = DAYS.slice(0, studyDays);
  const rows = state.schedules[selectedDay].map((subject, index) => `
    <label class="editor-row">
      <span class="editor-index">${String(index + 1).padStart(2, "0")}</span>
      <input class="field subject-input" data-index="${index}" aria-label="Урок ${index + 1}" maxlength="80" placeholder="Название урока" value="${escapeHtml(subject)}">
      <input class="field room-input" data-index="${index}" aria-label="Кабинет урока ${index + 1}" maxlength="40" placeholder="Кабинет" value="${escapeHtml(state.rooms[selectedDay][index])}">
      <span class="lesson-meta">${escapeHtml(state.bells[index])}</span>
    </label>`).join("");
  return `
    <div class="page-heading"><div><p class="eyebrow">редактор занятий / ${escapeHtml(state.selectedGroup)}</p><h1>Расписание · ${escapeHtml(state.selectedGroup)}</h1><p class="subtitle">Изменения автоматически сохраняются в этом браузере</p></div></div>
    <div class="day-picker">${shownDays.map(day => `<button class="day-button ${day === selectedDay ? "active" : ""}" data-day="${day}">${DAY_SHORT[day]}</button>`).join("")}</div>
    <section class="card"><div class="card-heading"><div><h2>${escapeHtml(DAY_NAMES[selectedDay])}</h2><p>Нажмите на предмет, чтобы изменить его</p></div><span class="tag">10 УРОКОВ</span></div><div class="editor-list">${rows}</div>
      <div class="button-row"><button class="button subtle" data-action="reset-day">Восстановить день</button><button class="button subtle" data-action="reset-all">Восстановить расписание группы</button></div>
    </section>`;
}

function renderBells() {
  const rows = state.bells.map((time, index) => `
    <label class="editor-row bell-editor-row">
      <span class="editor-index">${String(index + 1).padStart(2, "0")}</span>
      <span class="lesson-subject">Начало урока ${index + 1}</span>
      <input class="field time-field bell-input" type="time" step="60" data-index="${index}" aria-label="Время начала урока ${index + 1}" value="${escapeHtml(normalizeTime(time) || DEFAULT_BELLS[index])}">
    </label>`).join("");
  return `
    <div class="page-heading"><div><p class="eyebrow">общее время занятий</p><h1>Звонки</h1><p class="subtitle">Одинаковое время начала уроков для всех групп</p></div></div>
    <section class="card"><div class="card-heading"><div><h2>Расписание звонков</h2><p>Изменения сохраняются автоматически</p></div><span class="tag">24 ЧАСА</span></div><div class="editor-list">${rows}</div></section>`;
}

function renderSettings() {
  const owner = isOwner();
  const adminSession = isAdmin();
  return `
    <div class="page-heading"><div><p class="eyebrow">персонализация и синхронизация</p><h1>Настройки</h1><p class="subtitle">Настройте внешний вид, перенос и публикацию расписания</p></div></div>
    <div class="settings-grid">
      <section class="card"><div class="card-heading"><div><h2>Цветовая тема</h2><p>Тема запоминается на устройстве</p></div></div>
        <div class="theme-options">
          <button class="theme-button ${state.theme === "violet" ? "active" : ""}" data-theme="violet"><span class="theme-swatch violet"></span>Аметист</button>
          <button class="theme-button ${state.theme === "ocean" ? "active" : ""}" data-theme="ocean"><span class="theme-swatch ocean"></span>Океан</button>
          <button class="theme-button ${state.theme === "sunset" ? "active" : ""}" data-theme="sunset"><span class="theme-swatch sunset"></span>Закат</button>
        </div>
      </section>
      <section class="card"><div class="card-heading"><div><h2>Уведомления</h2><p>Узнавайте об изменениях расписания</p></div><span class="tag">PUSH</span></div>
        <p class="card-copy">${window.SlemeAndroid ? "Разрешите уведомления в настройках Android, чтобы получать сообщения об опубликованных изменениях." : "Push-уведомления доступны в установленном Android-приложении."}</p>
        <div class="button-row"><button class="button subtle" data-action="notification-settings" ${window.SlemeAndroid ? "" : "disabled"}>Настроить уведомления</button></div>
      </section>
      ${adminSession ? `<section class="card"><div class="card-heading"><div><h2>Перенос расписания</h2><p>Формат совместим с Android-приложением</p></div></div>
        <p class="card-copy">Скопируйте строку переноса или вставьте её сюда. Это кодирование для переноса, а не защита конфиденциальных данных.</p>
        <div class="button-row"><button class="button primary" data-action="copy-config">Скопировать строку</button></div>
        <textarea id="config-input" class="field code-area" placeholder="Вставьте строку переноса..." spellcheck="false"></textarea>
        <div class="button-row"><button class="button subtle" data-action="import-config">Импортировать</button></div>
        <p id="config-status" class="settings-status" aria-live="polite"></p>
      </section>` : ""}
      ${owner ? `<section class="card"><div class="card-heading"><div><h2>Управление администраторами</h2><p>Создавайте доступ по email и паролю</p></div><span class="tag">ВЛАДЕЛЕЦ</span></div>
        <p class="card-copy">Создание аккаунта и выдача роли выполняются через бесплатные Firebase Authentication и Firestore. Пароль не сохраняется. Администраторы могут менять расписание и звонки, но не могут добавлять/удалять группы или управлять другими администраторами.</p>
        <form id="add-admin-form" class="admin-account-form">
          <div class="admin-fields"><input class="field" id="new-admin-email" type="email" autocomplete="off" placeholder="Email нового администратора" required><input class="field" id="new-admin-password" type="password" autocomplete="new-password" minlength="6" placeholder="Пароль (не менее 6 символов)" required></div>
          <div class="button-row"><button class="button primary" type="submit">Создать администратора</button></div>
        </form>
        <div class="admin-account-list">${state.adminUids.length ? state.adminUids.map(uid => {
          const admin = state.admins.find(item => item.uid === uid);
          const email = admin?.email || `UID ${uid}`;
          return `<div class="admin-account-row"><span><strong>${escapeHtml(email)}</strong><small>Доступ администратора</small></span><button class="button danger" type="button" data-remove-admin="${escapeHtml(uid)}">Отозвать доступ</button></div>`;
        }).join("") : '<p class="card-copy">Дополнительных администраторов пока нет.</p>'}</div>
        <p id="admin-management-status" class="settings-status" aria-live="polite"></p>
      </section>` : ""}
      <section class="card"><div class="card-heading"><div><h2>Облачная синхронизация</h2><p>${adminSession ? "Вы вошли как администратор" : "Войдите в аккаунт администратора, чтобы опубликовать расписание"}</p></div><span class="tag">${adminSession ? "АДМИНИСТРАТОР" : "FIREBASE"}</span></div>
        ${adminSession ? owner ? `<p class="card-copy">Вы вошли как владелец. Расписание и звонки можно публиковать, а состав групп и администраторов изменять только с этой учётной записи.</p>
          <div class="button-row"><button class="button primary" data-action="publish">Сохранить в облако</button><button class="button subtle" data-action="logout-admin">Выйти из аккаунта</button></div>`
          : `<p class="card-copy">Как администратор вы можете менять расписание и звонки и сохранять их для всех пользователей.</p>
          <div class="button-row"><button class="button primary" data-action="publish">Сохранить в облако</button><button class="button subtle" data-action="logout-admin">Выйти из аккаунта</button></div>`
          : `<div class="admin-fields"><input class="field" id="admin-email" type="email" autocomplete="username" placeholder="Email администратора"><input class="field" id="admin-password" type="password" autocomplete="current-password" placeholder="Пароль администратора"></div>
          <div class="button-row"><button class="button primary" data-action="login-admin">Войти как администратор</button></div>`}
        <p id="cloud-settings-status" class="settings-status" aria-live="polite">${auth || window.SlemeAndroid ? "Связь с Firebase настраивается…" : "Запустите сайт через локальный веб-сервер для облачной синхронизации."}</p>
      </section>
      <div class="callout">Интерфейс сайта и Android-приложения общий. Расписание публикуется в облако только после нажатия «Сохранить в облако».</div>
    </div>`;
}

function render() {
  document.documentElement.dataset.theme = state.theme;
  const adminSession = isAdmin();
  currentGroupLabel.textContent = state.selectedGroup;
  groupSwitcher.setAttribute("aria-label", `Выбрана группа ${state.selectedGroup}. Нажмите, чтобы сменить`);
  appShell.classList.add("dashboard-design");
  appShell.classList.toggle("admin-session", adminSession);
  const groupDays = state.groupStudyDays[state.selectedGroup] === 6 ? 6 : 5;
  if (!DAYS.slice(0, groupDays).includes(selectedDay)) selectedDay = "monday";
  if (!adminSession && ADMIN_TABS.has(activeTab)) activeTab = "today";
  if (adminSession && PUBLIC_ONLY_TABS.has(activeTab)) activeTab = "today";
  document.querySelectorAll("[data-tab]").forEach(button => {
    const tab = button.dataset.tab;
    button.hidden = (ADMIN_TABS.has(tab) && !adminSession) || (PUBLIC_ONLY_TABS.has(tab) && adminSession);
    button.classList.toggle("active", button.dataset.tab === activeTab);
  });
  if (activeTab === "today") content.innerHTML = renderToday();
  if (activeTab === "countdown") {
    content.innerHTML = renderCountdown();
    renderCountdownState();
  }
  if (activeTab === "week") content.innerHTML = renderWeekSchedule();
  if (activeTab === "schedule") content.innerHTML = renderSchedule();
  if (activeTab === "bells") content.innerHTML = renderBells();
  if (activeTab === "settings") content.innerHTML = renderSettings();
  if (!groupPicker.hidden) renderGroupPicker();
}

function applyCloudSchedule(data) {
  if (Array.isArray(data.adminUids)) {
    state.adminUids = [...new Set(data.adminUids.filter(uid => typeof uid === "string"))];
    state.admins = state.admins.filter(admin => state.adminUids.includes(admin.uid));
    persist();
  }
  if (!Array.isArray(data.bells) || !data.bells.every(value => typeof value === "string")) {
    setCloudStatus("Ошибка формата расписания", "error");
    return;
  }
  state.bells = [...data.bells.slice(0, 10), ...DEFAULT_BELLS.slice(data.bells.length, 10)]
    .map((value, index) => normalizeTime(value) || DEFAULT_BELLS[index]);
  const cloudGroups = data.groups && typeof data.groups === "object" ? data.groups : {};
  const availableGroups = Object.keys(cloudGroups).filter(group => isValidGroupName(group));
  if (availableGroups.length) {
    state.groups = availableGroups;
    for (const group of Object.keys(state.groupSchedules)) {
      if (!state.groups.includes(group)) {
        delete state.groupSchedules[group];
        delete state.groupStudyDays[group];
      }
    }
  }
  for (const [group, schedule] of Object.entries(cloudGroups)) {
    if (isValidGroupName(group) && schedule && typeof schedule === "object") {
      state.groupSchedules[group] = normalizeSchedule(schedule, state.groupSchedules[group] || emptySchedule());
      state.groupStudyDays[group] = data.studyDays?.[group] === 6 ? 6 : state.groupStudyDays[group] === 6 ? 6 : 5;
    }
  }
  if (data.studyDays && typeof data.studyDays === "object") {
    for (const [group, days] of Object.entries(data.studyDays)) {
      if (isValidGroupName(group) && (days === 5 || days === 6)) state.groupStudyDays[group] = days;
    }
  }
  if (!cloudGroups["60ТО"] && DAYS.some(day => Array.isArray(data[day]))) {
    state.groupSchedules["60ТО"] = normalizeSchedule(data, state.groupSchedules["60ТО"] || DEFAULT_SCHEDULES);
  }
  if (!availableGroups.length && !state.groups.length) {
    state.groups = [...DEFAULT_GROUPS];
    for (const group of state.groups) {
      state.groupSchedules[group] = group === "60ТО" ? cloneSchedule(DEFAULT_SCHEDULES) : emptySchedule();
      state.groupStudyDays[group] = 5;
    }
  }
  if (!state.groups.includes(state.selectedGroup)) state.selectedGroup = state.groups[0] || "";
  state.schedules = cloneSchedule(state.groupSchedules[state.selectedGroup] || emptySchedule());
  persist();
  setCloudStatus("Синхронизировано", "online");
  render();
}

function attachCloudListener(user) {
  cloudUnsubscribe?.();
  cloudUnsubscribe = null;
  currentUser = user;
  if (!isAdmin()) {
    if (ADMIN_TABS.has(activeTab)) activeTab = "today";
  }
  render();
  const reference = firebaseApi.doc(firestore, "config", "main");
  cloudUnsubscribe = firebaseApi.onSnapshot(reference, snapshot => {
    if (snapshot.exists()) applyCloudSchedule(snapshot.data());
    else setCloudStatus(isAdmin() ? "Администратор" : "Облако подключено", "online");
  }, error => {
    console.error("Ошибка синхронизации расписания", error);
    setCloudStatus("Ошибка синхронизации", "error");
    const status = document.querySelector("#cloud-settings-status");
    if (status) setSettingsMessage(status, error.message || "Не удалось подключиться к Firestore.", "error");
  });
  setCloudStatus(isAdmin() ? "Администратор" : "Облако подключено", "online");
}

async function initializeCloud() {
  if (window.SlemeAndroid) {
    setCloudStatus("Подключаем Firebase");
    window.SlemeAndroid.initializeCloud();
    return;
  }
  try {
    const [appSdk, authSdk, firestoreSdk] = await Promise.all([
      import("https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js"),
      import("https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js"),
      import("https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js")
    ]);
    firebaseAppSdk = appSdk;
    firebaseAuthSdk = authSdk;
    firebaseApi = { ...authSdk, ...firestoreSdk };
    const response = await fetch("../app/google-services.json");
    if (!response.ok) throw new Error(`Не удалось загрузить Firebase-конфигурацию (${response.status}).`);
    const googleServices = await response.json();
    const client = googleServices.client?.find(item => item.client_info?.android_client_info?.package_name === "com.example.phonestarter");
    const apiKey = client?.api_key?.[0]?.current_key;
    const appId = client?.client_info?.mobilesdk_app_id;
    const projectId = googleServices.project_info?.project_id;
    if (!apiKey || !appId || !projectId) throw new Error("В Firebase-конфигурации не найдены параметры основного Android-приложения.");

    firebaseConfig = { apiKey, appId, projectId, authDomain: `${projectId}.firebaseapp.com`, messagingSenderId: googleServices.project_info.project_number };
    const app = appSdk.initializeApp(firebaseConfig);
    auth = authSdk.getAuth(app);
    firestore = firestoreSdk.getFirestore(app);
    authSdk.onAuthStateChanged(auth, async user => {
      if (user) {
        attachCloudListener(user);
      } else {
        try {
          await authSdk.signInAnonymously(auth);
        } catch (error) {
          console.error("Не удалось войти анонимно в Firebase", error);
          setCloudStatus("Firebase недоступен", "error");
        }
      }
    }, error => {
      console.error("Ошибка Firebase Authentication", error);
      setCloudStatus("Ошибка Firebase", "error");
    });
  } catch (error) {
    console.error("Облачная синхронизация не инициализирована", error);
    setCloudStatus(location.protocol === "file:" ? "Нужен локальный сервер" : "Облако недоступно", "error");
  }
}

function setSettingsMessage(node, message, kind = "") {
  node.textContent = message;
  node.classList.toggle("error", kind === "error");
  node.classList.toggle("success", kind === "success");
}

function buildConfig() {
  const sections = [`bells=${state.bells.join("|")}`];
  for (const day of DAYS) sections.push(`${day}=${state.schedules[day].map(value => value || "~").join("|")}`);
  const source = new TextEncoder().encode(sections.join(";"));
  const key = new TextEncoder().encode("SLEME-APP-KEY-2026");
  const encoded = source.map((byte, index) => byte ^ key[index % key.length]);
  let binary = "";
  for (const byte of encoded) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function parseConfig(raw) {
  let binary;
  try {
    binary = atob(raw.trim());
  } catch {
    return null;
  }
  const key = new TextEncoder().encode("SLEME-APP-KEY-2026");
  const bytes = Uint8Array.from(binary, (character, index) => character.charCodeAt(0) ^ key[index % key.length]);
  let decoded;
  try {
    decoded = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    return null;
  }
  const values = new Map(decoded.split(";").filter(section => section.includes("=")).map(section => [section.slice(0, section.indexOf("=")), section.slice(section.indexOf("=") + 1)]));
  const weekdays = DAYS.slice(0, 5);
  if (!values.has("bells") || weekdays.some(day => !values.has(day))) return null;
  const bells = values.get("bells").split("|").map(normalizeTime);
  const schedules = {};
  for (const day of weekdays) schedules[day] = values.get(day).split("|").map(value => value === "~" ? "" : value);
  schedules.saturday = values.has("saturday")
    ? values.get("saturday").split("|").map(value => value === "~" ? "" : value)
    : Array(10).fill("");
  if (bells.length !== 10 || DAYS.some(day => schedules[day].length !== 10)) return null;
  if (bells.some(value => !value)) return null;
  return { bells, schedules };
}

async function copyConfig() {
  const code = buildConfig();
  const status = document.querySelector("#config-status");
  if (window.SlemeAndroid) {
    window.SlemeAndroid.copyToClipboard(code);
    setSettingsMessage(status, "Строка скопирована. Формат совместим с Android-приложением.", "success");
    return;
  }
  try {
    await navigator.clipboard.writeText(code);
    setSettingsMessage(status, "Строка скопирована. Формат совместим с Android-приложением.", "success");
  } catch (error) {
    console.error("Не удалось скопировать строку в буфер обмена", error);
    document.querySelector("#config-input").value = code;
    document.querySelector("#config-input").focus();
    document.querySelector("#config-input").select();
    setSettingsMessage(status, "Автокопирование недоступно — строка вставлена в поле, скопируйте её вручную.", "error");
  }
}

function importConfig() {
  const input = document.querySelector("#config-input");
  const config = parseConfig(input.value);
  const status = document.querySelector("#config-status");
  if (!config) {
    setSettingsMessage(status, "Строка не распознана. Проверьте, что скопировали её полностью.", "error");
    return;
  }
  state.bells = config.bells;
  state.schedules = config.schedules;
  state.groupSchedules[state.selectedGroup] = cloneSchedule(config.schedules);
  persist();
  setSettingsMessage(status, "Расписание и звонки импортированы.", "success");
  showToast("Расписание и звонки обновлены");
  render();
}

async function loginAdmin() {
  const status = document.querySelector("#cloud-settings-status");
  const email = document.querySelector("#admin-email")?.value.trim();
  const password = document.querySelector("#admin-password")?.value;
  if (!email || !password) {
    setSettingsMessage(status, "Введите email и пароль администратора.", "error");
    return;
  }
  const button = content.querySelector('[data-action="login-admin"]');
  button.disabled = true;
  setSettingsMessage(status, "Выполняется вход…");
  if (window.SlemeAndroid) {
    window.SlemeAndroid.signInAdmin(email, password);
    return;
  }
  try {
    const result = await firebaseApi.signInWithEmailAndPassword(auth, email, password);
    if (result.user.uid !== ADMIN_UID &&
        result.user.email?.toLowerCase() !== OWNER_EMAIL &&
        !state.adminUids.includes(result.user.uid)) {
      await firebaseApi.signOut(auth);
      const currentStatus = document.querySelector("#cloud-settings-status");
      if (currentStatus) setSettingsMessage(currentStatus, "У этой учётной записи нет доступа администратора в тестовом сайте.", "error");
      return;
    }
    setSettingsMessage(status, "Вход администратора выполнен.", "success");
    render();
  } catch (error) {
    console.error("Ошибка входа администратора", error);
    setSettingsMessage(status, `Не удалось войти: ${error.message}`, "error");
  } finally {
    button.disabled = false;
  }
}

async function createAdminAccount(event) {
  event.preventDefault();
  if (!isOwner()) return;
  const emailInput = document.querySelector("#new-admin-email");
  const passwordInput = document.querySelector("#new-admin-password");
  const status = document.querySelector("#admin-management-status");
  const email = emailInput.value.trim().toLowerCase();
  const password = passwordInput.value;
  const button = event.currentTarget.querySelector('button[type="submit"]');
  if (!email || password.length < 6) {
    setSettingsMessage(status, "Введите корректный email и пароль не короче 6 символов.", "error");
    return;
  }
  if (!firebaseAppSdk || !firebaseAuthSdk || !firebaseConfig) {
    setSettingsMessage(status, "Для создания аккаунта запустите сайт через HTTP-сервер и дождитесь подключения Firebase.", "error");
    return;
  }
  if (state.admins.some(admin => admin.email.toLowerCase() === email)) {
    setSettingsMessage(status, "Этот пользователь уже добавлен.", "error");
    return;
  }

  button.disabled = true;
  setSettingsMessage(status, "Создаём учётную запись…");
  if (window.SlemeAndroid) {
    window.SlemeAndroid.createAdminAccount(email, password);
    return;
  }
  let secondaryApp;
  try {
    const appName = `sleme-admin-${Date.now()}`;
    secondaryApp = firebaseAppSdk.initializeApp(firebaseConfig, appName);
    const secondaryAuth = firebaseAuthSdk.getAuth(secondaryApp);
    let credential;
    try {
      credential = await firebaseAuthSdk.createUserWithEmailAndPassword(secondaryAuth, email, password);
    } catch (error) {
      if (error.code !== "auth/email-already-in-use") throw error;
      credential = await firebaseAuthSdk.signInWithEmailAndPassword(secondaryAuth, email, password);
    }
    if (!auth || !currentUser || !isOwner()) throw new Error("Сессия владельца потеряна; аккаунт не получил права.");
    await firebaseApi.updateDoc(
      firebaseApi.doc(firestore, "config", "main"),
      { adminUids: firebaseApi.arrayUnion(credential.user.uid) }
    );
    state.adminUids = [...new Set([...state.adminUids, credential.user.uid])];
    state.admins = [...state.admins.filter(admin => admin.uid !== credential.user.uid), {
      uid: credential.user.uid,
      email: credential.user.email || email
    }];
    persist();
    passwordInput.value = "";
    render();
    setSettingsMessage(document.querySelector("#admin-management-status"), `Аккаунт ${email} получил права администратора. Пароль не сохраняется.`, "success");
  } catch (error) {
    console.error("Не удалось создать администратора", error);
    setSettingsMessage(status, `Не удалось выдать роль администратора: ${error.message}`, "error");
  } finally {
    if (secondaryApp) {
      try {
        const secondaryAuth = firebaseAuthSdk.getAuth(secondaryApp);
        await firebaseAuthSdk.signOut(secondaryAuth);
        await firebaseAppSdk.deleteApp(secondaryApp);
      } catch (error) {
        console.error("Не удалось закрыть вспомогательную Firebase-сессию", error);
      }
    }
    const submitButton = content.querySelector('#add-admin-form button[type="submit"]');
    if (submitButton) submitButton.disabled = false;
  }
}

async function removeAdminAccount(uid) {
  const normalizedUid = typeof uid === "string" ? uid.trim() : "";
  if (!isOwner() || !normalizedUid) return;

  const admin = state.admins.find(item => item.uid === normalizedUid);
  const label = admin?.email || `UID ${normalizedUid}`;
  if (!state.adminUids.includes(normalizedUid)) {
    state.adminUids = state.adminUids.filter(item => item !== normalizedUid);
    state.admins = state.admins.filter(item => item.uid !== normalizedUid);
    persist();
    render();
    setSettingsMessage(document.querySelector("#admin-management-status"), `Права администратора ${label} уже отозваны.`, "success");
    return;
  }

  if (!window.confirm(`Отозвать права администратора ${label}? Сам аккаунт Firebase останется существовать.`)) return;
  if (window.SlemeAndroid) {
    window.SlemeAndroid.removeAdminAccount(normalizedUid);
    return;
  }
  try {
    const docRef = firebaseApi.doc(firestore, "config", "main");
    const snapshot = await firebaseApi.getDoc(docRef);
    const currentAdmins = Array.isArray(snapshot.data()?.adminUids) ? snapshot.data().adminUids : [];
    if (!currentAdmins.includes(normalizedUid)) {
      state.adminUids = state.adminUids.filter(item => item !== normalizedUid);
      state.admins = state.admins.filter(item => item.uid !== normalizedUid);
      persist();
      render();
      setSettingsMessage(document.querySelector("#admin-management-status"), `Права администратора ${label} уже отозваны.`, "success");
      return;
    }
    await firebaseApi.updateDoc(docRef, { adminUids: firebaseApi.arrayRemove(normalizedUid) });
    state.adminUids = state.adminUids.filter(item => item !== normalizedUid);
    state.admins = state.admins.filter(item => item.uid !== normalizedUid);
    persist();
    render();
    setSettingsMessage(document.querySelector("#admin-management-status"), `Роль администратора ${label} отозвана. Его аккаунт Firebase не удалён.`, "success");
  } catch (error) {
    console.error("Не удалось синхронизировать список администраторов", error);
    setSettingsMessage(
      document.querySelector("#admin-management-status"),
      `Не удалось отозвать роль в облаке: ${error.message}`,
      "error"
    );
  }
}

async function publishSchedule() {
  const status = document.querySelector("#cloud-settings-status");
  if (!isAdmin()) {
    setSettingsMessage(status, "Для публикации войдите как администратор.", "error");
    return;
  }
  const button = content.querySelector('[data-action="publish"]');
  button.disabled = true;
  setSettingsMessage(status, "Сохраняем расписание в облако…");
  state.groupSchedules[state.selectedGroup] = cloneSchedule(state.schedules);
  const groups = Object.fromEntries(groupNames().map(group => [group, cloneSchedule(state.groupSchedules[group])]));
  const payload = { bells: state.bells, groups, studyDays: { ...state.groupStudyDays }, adminUids: state.adminUids };
  const legacySchedule = groups["60ТО"] || groups[Object.keys(groups)[0]] || emptySchedule();
  for (const day of DAYS) payload[day] = legacySchedule[day];
  if (window.SlemeAndroid) {
    window.SlemeAndroid.publishSchedule(JSON.stringify(payload));
    return;
  }
  try {
    await firebaseApi.setDoc(firebaseApi.doc(firestore, "config", "main"), payload);
    setSettingsMessage(status, "Расписание опубликовано для подключённых клиентов.", "success");
    setCloudStatus("Опубликовано", "online");
    showToast("Расписание опубликовано");
  } catch (error) {
    console.error("Не удалось опубликовать расписание", error);
    setSettingsMessage(status, `Ошибка сохранения: ${error.message}`, "error");
    setCloudStatus("Ошибка публикации", "error");
  } finally {
    button.disabled = false;
  }
}

content.addEventListener("click", async event => {
  const weekDayButton = event.target.closest("[data-week-day]");
  if (weekDayButton) {
    const target = document.querySelector(`#week-day-${weekDayButton.dataset.weekDay}`);
    if (target) {
      const contentTop = content.getBoundingClientRect().top;
      const targetTop = target.getBoundingClientRect().top;
      content.scrollTo({
        top: content.scrollTop + targetTop - contentTop - 8,
        behavior: "smooth"
      });
    }
    return;
  }
  const dayButton = event.target.closest("[data-day]");
  if (dayButton) {
    if (!isAdmin()) return;
    selectedDay = dayButton.dataset.day;
    render();
    return;
  }
  const themeButton = event.target.closest(".theme-button[data-theme]");
  if (themeButton) {
    setTheme(themeButton.dataset.theme);
    render();
    return;
  }
  const removeAdminButton = event.target.closest("[data-remove-admin]");
  if (removeAdminButton) {
    await removeAdminAccount(removeAdminButton.dataset.removeAdmin);
    return;
  }
  const actionButton = event.target.closest("[data-action]");
  if (!actionButton) return;
  if (["reset-day", "reset-all", "copy-config", "import-config", "publish"].includes(actionButton.dataset.action)
      && !isAdmin()) {
    return;
  }
  switch (actionButton.dataset.action) {
    case "reset-day":
      state.schedules[selectedDay] = state.selectedGroup === "60ТО"
        ? [...DEFAULT_SCHEDULES[selectedDay]]
        : Array(10).fill("");
      persist();
      render();
      showToast(`${DAY_NAMES[selectedDay]} восстановлен`);
      break;
    case "reset-all":
      state.schedules = state.selectedGroup === "60ТО"
        ? cloneSchedule(DEFAULT_SCHEDULES)
        : emptySchedule();
      state.groupSchedules[state.selectedGroup] = cloneSchedule(state.schedules);
      persist();
      render();
      showToast(`Расписание группы ${state.selectedGroup} очищено`);
      break;
    case "copy-config":
      await copyConfig();
      break;
    case "import-config":
      importConfig();
      break;
    case "login-admin":
      await loginAdmin();
      break;
    case "publish":
      await publishSchedule();
      break;
    case "notification-settings":
      if (window.SlemeAndroid) {
        window.SlemeAndroid.openNotificationSettings();
      } else {
        showToast("Push-уведомления доступны в приложении Android");
      }
      break;
    case "logout-admin":
      if (window.SlemeAndroid) {
        window.SlemeAndroid.signOutAdmin();
        return;
      }
      try {
        await firebaseApi.signOut(auth);
        setSettingsMessage(document.querySelector("#cloud-settings-status"), "Вы вышли из аккаунта.");
        render();
      } catch (error) {
        console.error("Не удалось выйти из аккаунта", error);
        setSettingsMessage(document.querySelector("#cloud-settings-status"), `Ошибка выхода: ${error.message}`, "error");
      }
      break;
  }
});

groupSwitcher.addEventListener("click", () => renderGroupPicker());

groupPicker.addEventListener("click", event => {
  const deleteButton = event.target.closest("[data-delete-group]");
  if (deleteButton) {
    deleteGroup(deleteButton.dataset.deleteGroup);
    return;
  }
  const groupButton = event.target.closest("[data-group]");
  if (groupButton) {
    selectGroup(groupButton.dataset.group);
    return;
  }
  if (event.target.closest("[data-group-close]")) closeGroupPicker();
});

content.addEventListener("submit", event => {
  if (event.target.id === "add-admin-form") createAdminAccount(event);
});

groupPicker.addEventListener("submit", event => {
  if (event.target.id !== "add-group-form") return;
  event.preventDefault();
  addGroup(document.querySelector("#new-group-name").value);
});

groupPicker.addEventListener("change", event => {
  if (!event.target.matches('input[name="new-group-days"]')) return;
  groupPicker.querySelectorAll(".study-days-option").forEach(option => {
    option.classList.toggle("active", option.contains(event.target));
  });
});

window.onAndroidCloudState = result => {
  currentUser = result.uid ? { uid: result.uid, email: result.email || null } : null;
  if (!isAdmin()) {
    if (ADMIN_TABS.has(activeTab)) activeTab = "today";
  }
  if (result.data) {
    applyCloudSchedule(result.data);
  } else {
    setCloudStatus(
      result.error ? "Ошибка синхронизации" : isAdmin() ? "Администратор" : "Облако подключено",
      result.error ? "error" : "online"
    );
    render();
  }
  if (result.error) {
    const status = document.querySelector("#cloud-settings-status");
    if (status) setSettingsMessage(status, result.error, "error");
  }
};

window.onAndroidAdminLogin = (success, message) => {
  const status = document.querySelector("#cloud-settings-status");
  const button = content.querySelector('[data-action="login-admin"]');
  if (button) button.disabled = false;
  if (success) {
    render();
    showToast(message || "Вход администратора выполнен");
  } else if (status) {
    setSettingsMessage(status, message || "Не удалось войти.", "error");
  }
};

window.onAndroidAdminLogout = (success, message) => {
  if (success) {
    activeTab = "today";
    currentUser = null;
    render();
    showToast(message || "Вы вышли из аккаунта администратора");
  } else {
    const status = document.querySelector("#cloud-settings-status");
    if (status) setSettingsMessage(status, message || "Не удалось выйти из аккаунта.", "error");
  }
};

window.onAndroidAdminCreated = (success, uid, email, message) => {
  const status = document.querySelector("#admin-management-status");
  const button = content.querySelector('#add-admin-form button[type="submit"]');
  if (button) button.disabled = false;
  const passwordInput = document.querySelector("#new-admin-password");
  if (passwordInput) passwordInput.value = "";
  if (success && uid) {
    state.adminUids = [...new Set([...state.adminUids, uid])];
    state.admins = [...state.admins.filter(admin => admin.uid !== uid), { uid, email }];
    persist();
    render();
  }
  const currentStatus = document.querySelector("#admin-management-status") || status;
  if (currentStatus) setSettingsMessage(currentStatus, message || "Не удалось изменить права.", success ? "success" : "error");
};

window.onAndroidAdminRemoved = (success, uid, message) => {
  const status = document.querySelector("#admin-management-status");
  if (success) {
    state.adminUids = state.adminUids.filter(item => item !== uid);
    state.admins = state.admins.filter(item => item.uid !== uid);
    persist();
    render();
  }
  const currentStatus = document.querySelector("#admin-management-status") || status;
  if (currentStatus) setSettingsMessage(currentStatus, message || "Не удалось изменить права.", success ? "success" : "error");
};

window.onAndroidPublish = (success, message) => {
  const status = document.querySelector("#cloud-settings-status");
  const button = content.querySelector('[data-action="publish"]');
  if (button) button.disabled = false;
  if (status) setSettingsMessage(status, message || (success ? "Расписание опубликовано." : "Ошибка публикации."), success ? "success" : "error");
  if (success) showToast("Расписание опубликовано");
};

content.addEventListener("input", event => {
  const subject = event.target.closest(".subject-input");
  if (subject) {
    if (!isAdmin()) return;
    state.schedules[selectedDay][Number(subject.dataset.index)] = subject.value;
    persist();
    return;
  }
  const bell = event.target.closest(".bell-input");
  if (bell && bell.value) {
    if (!isAdmin()) return;
    state.bells[Number(bell.dataset.index)] = bell.value;
    persist();
  }
});

content.addEventListener("change", async event => {
  const bell = event.target.closest(".bell-input");
  if (!bell || !isAdmin()) return;
  const normalized = normalizeTime(bell.value);
  if (!normalized) {
    bell.value = state.bells[Number(bell.dataset.index)] || DEFAULT_BELLS[Number(bell.dataset.index)];
    showToast("Укажите корректное время в формате часы:минуты");
    return;
  }
  state.bells[Number(bell.dataset.index)] = normalized;
  bell.value = normalized;
  persist();
});

document.addEventListener("click", event => {
  const tabButton = event.target.closest("[data-tab]");
  if (!tabButton) return;
  if (ADMIN_TABS.has(tabButton.dataset.tab) && !isAdmin()) {
    activeTab = "today";
    render();
    return;
  }
  if (PUBLIC_ONLY_TABS.has(tabButton.dataset.tab) && isAdmin()) {
    activeTab = "today";
    render();
    return;
  }
  activeTab = tabButton.dataset.tab;
  render();
});

setTheme(state.theme);
render();
renderGroupPicker();
window.setInterval(() => {
  if (activeTab === "countdown") renderCountdownState();
  if (activeTab === "today") {
    if (new Date().toDateString() !== displayedToday) render();
  }
}, 1000);
initializeCloud();
