const DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday"];
const DAY_NAMES = { monday: "Понедельник", tuesday: "Вторник", wednesday: "Среда", thursday: "Четверг", friday: "Пятница" };
const DAY_SHORT = { monday: "ПН", tuesday: "ВТ", wednesday: "СР", thursday: "ЧТ", friday: "ПТ" };
const ADMIN_UID = "3hZ5bKEPYmSQ4TaH783ZJGiNyTv2";
const DEFAULT_BELLS = ["08:30", "09:20", "10:20", "11:20", "12:10", "13:00", "13:50", "14:40", "15:20", "16:10"];
const DEFAULT_SCHEDULES = {
  monday: ["Русский", "Математика", "История", "Физика", "Литература", "Химия", "География", "Иностранный", "Технология", "Физкультура"],
  tuesday: ["Математика", "Русский", "Биология", "Обществознание", "Информатика", "География", "Музыка", "ОБЖ", "Труд", "Физкультура"],
  wednesday: ["Алгебра", "Литература", "Химия", "История", "Физика", "Русский", "География", "Черчение", "Биология", "Физкультура"],
  thursday: ["Математика", "Русский", "Английский", "Информатика", "Физика", "География", "История", "Химия", "ОБЖ", "Физкультура"],
  friday: ["Русский", "Алгебра", "География", "Литература", "История", "Английский", "Физкультура", "Музыка", "Технология", "Гимнастика"]
};
const DEFAULT_GROUPS = ["60ТО", "1ИСО", "61ТО"];
const PUBLIC_TABS = new Set(["today", "countdown", "settings"]);
const ADMIN_TABS = new Set(["schedule", "bells"]);
const content = document.querySelector("#content");
const appShell = document.querySelector(".app-shell");
const cloudIndicator = document.querySelector("#cloud-indicator");
const cloudLabel = document.querySelector("#cloud-label");
const toastNode = document.querySelector("#toast");
const groupPicker = document.querySelector("#group-picker");
const groupSwitcher = document.querySelector("#group-switcher");
const currentGroupLabel = document.querySelector("#current-group");

let state = readLocalState();
let activeTab = "today";
let selectedDay = weekdayKey(new Date());
let auth = null;
let firestore = null;
let firebaseApi = null;
let currentUser = null;
let cloudUnsubscribe = null;
let toastTimer = 0;
let displayedToday = "";

function readLocalState() {
  let saved = {};
  try {
    saved = JSON.parse(localStorage.getItem("sleme.web.state") || "{}");
  } catch (error) {
    console.error("Не удалось прочитать сохранённое расписание", error);
  }
  const groupSchedules = {};
  const storedGroups = saved.groupSchedules && typeof saved.groupSchedules === "object"
    ? saved.groupSchedules
    : {};
  for (const group of DEFAULT_GROUPS) {
    groupSchedules[group] = normalizeSchedule(
      storedGroups[group] || (group === "60ТО" ? saved.schedules : null),
      group === "60ТО" ? DEFAULT_SCHEDULES : emptySchedule()
    );
  }
  for (const [group, schedule] of Object.entries(storedGroups)) {
    if (!DEFAULT_GROUPS.includes(group) && isValidGroupName(group)) {
      groupSchedules[group] = normalizeSchedule(schedule, emptySchedule());
    }
  }
  const schedules = groupSchedules["60ТО"];
  const bells = Array.isArray(saved.bells)
    ? [...saved.bells.slice(0, 10), ...DEFAULT_BELLS.slice(saved.bells.length, 10)].slice(0, 10)
      .map((value, index) => normalizeTime(value) || DEFAULT_BELLS[index])
    : [...DEFAULT_BELLS];
  const theme = ["violet", "ocean", "sunset"].includes(saved.theme) ? saved.theme : "violet";
  return {
    bells,
    schedules,
    groupSchedules,
    selectedGroup: "60ТО",
    theme
  };
}

function persist() {
  state.groupSchedules[state.selectedGroup] = cloneSchedule(state.schedules);
  localStorage.setItem("sleme.web.state", JSON.stringify(state));
}

function emptySchedule() {
  return Object.fromEntries(DAYS.map(day => [day, Array(10).fill("")]));
}

function normalizeSchedule(source, fallback) {
  return Object.fromEntries(DAYS.map(day => {
    const values = source?.[day];
    return [day, Array.isArray(values)
      ? [...values.slice(0, 10), ...Array(10).fill("")].slice(0, 10).map(value => String(value))
      : [...fallback[day]]];
  }));
}

function cloneSchedule(schedule) {
  return Object.fromEntries(DAYS.map(day => [day, [...schedule[day]]]));
}

function isValidGroupName(value) {
  return typeof value === "string" && /^[\p{L}\p{N} _-]{1,24}$/u.test(value.trim());
}

function groupNames() {
  return [...new Set([...DEFAULT_GROUPS, ...Object.keys(state.groupSchedules)])];
}

function setTheme(theme) {
  state.theme = theme;
  document.documentElement.dataset.theme = theme;
  persist();
}

function setCloudStatus(message, kind = "") {
  cloudLabel.textContent = message;
  cloudIndicator.classList.toggle("online", kind === "online");
  cloudIndicator.classList.toggle("error", kind === "error");
}

function showToast(message) {
  toastNode.textContent = message;
  toastNode.classList.add("show");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toastNode.classList.remove("show"), 2800);
}

function renderGroupPicker() {
  const admin = currentUser?.uid === ADMIN_UID;
  groupPicker.innerHTML = `
    <div class="group-picker-backdrop"></div>
    <section class="group-picker-card" role="dialog" aria-modal="true" aria-labelledby="group-picker-title">
      <div class="group-picker-heading">
        <div><p class="eyebrow">sleme program</p><h2 id="group-picker-title">Выберите группу</h2><p class="subtitle">Покажем расписание выбранной группы</p></div>
        ${state.groupChosen ? '<button class="group-picker-close" type="button" data-group-close aria-label="Закрыть">×</button>' : ""}
      </div>
      <div class="group-options">
        ${groupNames().map(group => `<button class="group-option ${group === state.selectedGroup ? "active" : ""}" type="button" data-group="${escapeHtml(group)}"><strong>${escapeHtml(group)}</strong><span>${group === "60ТО" ? "Текущее расписание" : "Расписание группы"}</span></button>`).join("")}
      </div>
      ${admin ? `<form class="add-group-form" id="add-group-form">
        <label for="new-group-name">Добавить группу</label>
        <div class="add-group-controls"><input class="field" id="new-group-name" maxlength="24" placeholder="Например, 62ТО" autocomplete="off"><button class="button primary" type="submit">Добавить</button></div>
        <p class="settings-status" id="group-picker-status" aria-live="polite"></p>
      </form>` : ""}
      ${!admin ? '<p class="group-picker-note">Чтобы создать или изменить расписание групп, войдите как администратор в настройках.</p>' : ""}
    </section>`;
  groupPicker.hidden = false;
}

function closeGroupPicker() {
  if (!state.groupChosen) return;
  groupPicker.hidden = true;
}

function selectGroup(group) {
  if (!groupNames().includes(group)) return;
  state.groupSchedules[state.selectedGroup] = cloneSchedule(state.schedules);
  state.selectedGroup = group;
  state.schedules = cloneSchedule(state.groupSchedules[group] || emptySchedule());
  state.groupChosen = true;
  persist();
  closeGroupPicker();
  render();
}

function addGroup(groupName) {
  const name = groupName.trim().toLocaleUpperCase("ru-RU");
  const status = document.querySelector("#group-picker-status");
  if (!isValidGroupName(name)) {
    setSettingsMessage(status, "Используйте 1–24 буквы или цифры, пробел, дефис или подчёркивание.", "error");
    return;
  }
  if (groupNames().some(group => group.toLocaleUpperCase("ru-RU") === name)) {
    setSettingsMessage(status, `Группа «${name}» уже существует.`, "error");
    return;
  }
  state.groupSchedules[name] = emptySchedule();
  persist();
  selectGroup(name);
  showToast(`Группа «${name}» добавлена`);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

function weekdayKey(date) {
  const index = date.getDay();
  if (index === 0 || index === 6) return "monday";
  return DAYS[index - 1];
}

function currentDateLabel(date = new Date()) {
  return new Intl.DateTimeFormat("ru-RU", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(date);
}

function normalizeTime(value) {
  const match = /^(\d{1,2}):([0-5]\d)$/.exec(String(value));
  if (!match || Number(match[1]) > 23) return "";
  return `${String(Number(match[1])).padStart(2, "0")}:${match[2]}`;
}

function timeToDate(date, time) {
  const match = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(normalizeTime(time));
  if (!match) return null;
  const target = new Date(date);
  target.setHours(Number(match[1]), Number(match[2]), 0, 0);
  return target;
}

function nextLesson(now = new Date()) {
  const todaysKey = weekdayKey(now);
  const times = state.bells;
  for (let index = 0; index < times.length; index += 1) {
    const startsAt = timeToDate(now, times[index]);
    if (startsAt && startsAt > now) {
      return { day: todaysKey, index, date: startsAt, name: state.schedules[todaysKey][index] || `Урок ${index + 1}`, time: times[index] };
    }
  }
  for (let offset = 1; offset <= 7; offset += 1) {
    const startsAt = new Date(now);
    startsAt.setDate(startsAt.getDate() + offset);
    if (startsAt.getDay() === 0 || startsAt.getDay() === 6) continue;
    const day = DAYS[startsAt.getDay() - 1];
    const startTime = times.find(value => timeToDate(now, value)) || DEFAULT_BELLS[0];
    const lessonDate = timeToDate(startsAt, startTime);
    if (!lessonDate) continue;
    return { day, index: 0, date: lessonDate, name: state.schedules[day][0] || "Урок 1", time: startTime };
  }
  return null;
}

function durationLabel(milliseconds) {
  const total = Math.max(0, Math.floor(milliseconds / 1000));
  return [Math.floor(total / 3600), Math.floor((total % 3600) / 60), total % 60]
    .map(value => String(value).padStart(2, "0")).join(":");
}

function nextStartForToday(date = new Date()) {
  const key = weekdayKey(date);
  return state.bells.findIndex(value => {
    const start = timeToDate(date, value);
    return start && start > date;
  });
}

function renderToday() {
  const key = weekdayKey(new Date());
  displayedToday = key;
  const soonIndex = nextStartForToday();
  const lessons = state.schedules[key].map((subject, index) => `
    <div class="lesson-row ${index === soonIndex ? "next" : ""}">
      <span class="lesson-index">${String(index + 1).padStart(2, "0")}</span>
      <span class="lesson-subject">${escapeHtml(subject || "—")}</span>
      <span class="lesson-meta">${index === soonIndex ? '<span class="now-label">ДАЛЕЕ</span>' : ""}${escapeHtml(state.bells[index] || "—")}</span>
    </div>`).join("");
  return `
    <div class="page-heading">
      <div><p class="eyebrow">sleme program / ${escapeHtml(state.selectedGroup)}</p><h2>Расписание на сегодня</h2><p class="subtitle">${escapeHtml(DAY_NAMES[key])} · ${escapeHtml(state.selectedGroup)}</p></div>
      <span class="date-chip">${escapeHtml(currentDateLabel())}</span>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><span class="stat-icon">▦</span><span><small>Уроков сегодня</small><strong>${state.schedules[key].filter(Boolean).length}</strong></span></div>
      <div class="stat-card"><span class="stat-icon">◴</span><span><small>Следующий урок</small><strong>${soonIndex >= 0 ? escapeHtml(state.bells[soonIndex]) : "—"}</strong></span></div>
      <div class="stat-card"><span class="stat-icon">♧</span><span><small>Учебная неделя</small><strong>Понедельник — пятница</strong></span></div>
    </div>
    <section class="card">
      <div class="card-heading"><div><h2>План дня</h2><p>Предметы и время начала занятий</p></div><span class="tag">${escapeHtml(DAY_SHORT[key])}</span></div>
      <div class="lesson-list">${lessons}</div>
    </section>`;
}

function renderCountdown(now = new Date()) {
  const next = nextLesson(now);
  const countdown = next ? durationLabel(next.date - now) : "—";
  const details = next
    ? `<p class="countdown-name">${escapeHtml(next.name)} · ${escapeHtml(DAY_NAMES[next.day])}</p><div class="countdown-clock">${countdown}</div><p class="countdown-caption">Начало ${escapeHtml(next.time)} · ${escapeHtml(currentDateLabel(next.date))}</p>`
    : `<p class="countdown-name">Расписание занятий не найдено</p><div class="countdown-clock">—</div>`;
  const upcoming = next ? state.bells.slice(next.day === weekdayKey(now) ? next.index : 0, (next.day === weekdayKey(now) ? next.index : 0) + 3) : [];
  return `
    <div class="page-heading"><div><p class="eyebrow">таймер в реальном времени</p><h1>До следующего урока</h1><p class="subtitle">${escapeHtml(state.selectedGroup)} · Обратный отсчёт обновляется каждую секунду</p></div></div>
    <div class="countdown-layout">
      <section class="card countdown-card"><span class="hourglass">◴</span>${details}</section>
      <section class="card"><div class="card-heading"><div><h2>Ближайшие звонки</h2><p>${next ? escapeHtml(DAY_NAMES[next.day]) : "Расписание"}</p></div></div>
        <div class="mini-list">${upcoming.length ? upcoming.map((time, index) => `<div class="mini-lesson"><span>${escapeHtml(state.schedules[next.day][next.index + index] || `Урок ${next.index + index + 1}`)}</span><span>${escapeHtml(time)}</span></div>`).join("") : '<div class="empty-state">Нет ближайших звонков</div>'}</div>
      </section>
    </div>`;
}

function renderSchedule() {
  const rows = state.schedules[selectedDay].map((subject, index) => `
    <label class="editor-row">
      <span class="editor-index">${String(index + 1).padStart(2, "0")}</span>
      <input class="field subject-input" data-index="${index}" aria-label="Урок ${index + 1}" maxlength="80" placeholder="Название урока" value="${escapeHtml(subject)}">
      <span class="lesson-meta">${escapeHtml(state.bells[index])}</span>
    </label>`).join("");
  return `
    <div class="page-heading"><div><p class="eyebrow">редактор занятий / ${escapeHtml(state.selectedGroup)}</p><h1>Расписание · ${escapeHtml(state.selectedGroup)}</h1><p class="subtitle">Изменения автоматически сохраняются в этом браузере</p></div></div>
    <div class="day-picker">${DAYS.map(day => `<button class="day-button ${day === selectedDay ? "active" : ""}" data-day="${day}">${DAY_SHORT[day]}</button>`).join("")}</div>
    <section class="card"><div class="card-heading"><div><h2>${escapeHtml(DAY_NAMES[selectedDay])}</h2><p>Нажмите на предмет, чтобы изменить его</p></div><span class="tag">10 УРОКОВ</span></div><div class="editor-list">${rows}</div>
      <div class="button-row"><button class="button subtle" data-action="reset-day">Восстановить день</button><button class="button subtle" data-action="reset-all">Восстановить расписание группы</button></div>
    </section>`;
}

function renderBells() {
  const rows = state.bells.map((time, index) => `
    <label class="editor-row bell-editor-row">
      <span class="editor-index">${String(index + 1).padStart(2, "0")}</span>
      <span class="lesson-subject">Начало урока ${index + 1}</span>
      <input class="field time-field bell-input" type="time" step="60" data-index="${index}" aria-label="Время начала урока ${index + 1}" value="${escapeHtml(normalizeTime(time) || DEFAULT_BELLS[index])}">
    </label>`).join("");
  return `
    <div class="page-heading"><div><p class="eyebrow">общее время занятий</p><h1>Звонки</h1><p class="subtitle">Одинаковое время начала уроков для всех групп</p></div></div>
    <section class="card"><div class="card-heading"><div><h2>Расписание звонков</h2><p>Изменения сохраняются автоматически</p></div><span class="tag">24 ЧАСА</span></div><div class="editor-list">${rows}</div></section>`;
}

function renderSettings() {
  const isAdmin = currentUser?.uid === ADMIN_UID;
  return `
    <div class="page-heading"><div><p class="eyebrow">персонализация и синхронизация</p><h1>Настройки</h1><p class="subtitle">Настройте внешний вид, перенос и публикацию расписания</p></div></div>
    <div class="settings-grid">
      <section class="card"><div class="card-heading"><div><h2>Цветовая тема</h2><p>Тема запоминается на устройстве</p></div></div>
        <div class="theme-options">
          <button class="theme-button ${state.theme === "violet" ? "active" : ""}" data-theme="violet"><span class="theme-swatch violet"></span>Аметист</button>
          <button class="theme-button ${state.theme === "ocean" ? "active" : ""}" data-theme="ocean"><span class="theme-swatch ocean"></span>Океан</button>
          <button class="theme-button ${state.theme === "sunset" ? "active" : ""}" data-theme="sunset"><span class="theme-swatch sunset"></span>Закат</button>
        </div>
      </section>
      <section class="card"><div class="card-heading"><div><h2>Уведомления</h2><p>Узнавайте об изменениях расписания</p></div><span class="tag">PUSH</span></div>
        <p class="card-copy">${window.SlemeAndroid ? "Разрешите уведомления в настройках Android, чтобы получать сообщения об опубликованных изменениях." : "Push-уведомления доступны в установленном Android-приложении."}</p>
        <div class="button-row"><button class="button subtle" data-action="notification-settings" ${window.SlemeAndroid ? "" : "disabled"}>Настроить уведомления</button></div>
      </section>
      ${isAdmin ? `<section class="card"><div class="card-heading"><div><h2>Перенос расписания</h2><p>Формат совместим с Android-приложением</p></div></div>
        <p class="card-copy">Скопируйте строку переноса или вставьте её сюда. Это кодирование для переноса, а не защита конфиденциальных данных.</p>
        <div class="button-row"><button class="button primary" data-action="copy-config">Скопировать строку</button></div>
        <textarea id="config-input" class="field code-area" placeholder="Вставьте строку переноса..." spellcheck="false"></textarea>
        <div class="button-row"><button class="button subtle" data-action="import-config">Импортировать</button></div>
        <p id="config-status" class="settings-status" aria-live="polite"></p>
      </section>` : ""}
      <section class="card"><div class="card-heading"><div><h2>Облачная синхронизация</h2><p>${isAdmin ? "Вы вошли как администратор" : "Войдите в аккаунт администратора, чтобы опубликовать расписание"}</p></div><span class="tag">${isAdmin ? "АДМИНИСТРАТОР" : "FIREBASE"}</span></div>
        ${isAdmin ? `<p class="card-copy">Изменения останутся локальными, пока вы не нажмёте «Сохранить в облако». Публикация обновит данные для подключённых клиентов.</p>
          <div class="button-row"><button class="button primary" data-action="publish">Сохранить в облако</button><button class="button subtle" data-action="logout-admin">Выйти из аккаунта</button></div>`
          : `<div class="admin-fields"><input class="field" id="admin-email" type="email" autocomplete="username" placeholder="Email администратора"><input class="field" id="admin-password" type="password" autocomplete="current-password" placeholder="Пароль администратора"></div>
          <div class="button-row"><button class="button primary" data-action="login-admin">Войти как администратор</button></div>`}
        <p id="cloud-settings-status" class="settings-status" aria-live="polite">${auth || window.SlemeAndroid ? "Связь с Firebase настраивается…" : "Запустите сайт через локальный веб-сервер для облачной синхронизации."}</p>
      </section>
      <div class="callout">Интерфейс сайта и Android-приложения общий. Расписание публикуется в облако только после нажатия «Сохранить в облако».</div>
    </div>`;
}

function render() {
  document.documentElement.dataset.theme = state.theme;
  const isAdmin = currentUser?.uid === ADMIN_UID;
  currentGroupLabel.textContent = state.selectedGroup;
  groupSwitcher.setAttribute("aria-label", `Выбрана группа ${state.selectedGroup}. Нажмите, чтобы сменить`);
  appShell.classList.add("dashboard-design");
  appShell.classList.toggle("admin-session", isAdmin);
  if (!isAdmin && ADMIN_TABS.has(activeTab)) activeTab = "today";
  document.querySelectorAll("[data-tab]").forEach(button => {
    const adminOnly = ADMIN_TABS.has(button.dataset.tab);
    button.hidden = adminOnly && !isAdmin;
    button.classList.toggle("active", button.dataset.tab === activeTab);
  });
  if (activeTab === "today") content.innerHTML = renderToday();
  if (activeTab === "countdown") content.innerHTML = renderCountdown();
  if (activeTab === "schedule") content.innerHTML = renderSchedule();
  if (activeTab === "bells") content.innerHTML = renderBells();
  if (activeTab === "settings") content.innerHTML = renderSettings();
  if (!groupPicker.hidden) renderGroupPicker();
}

function applyCloudSchedule(data) {
  if (!Array.isArray(data.bells) || !data.bells.every(value => typeof value === "string")) {
    setCloudStatus("Ошибка формата расписания", "error");
    return;
  }
  state.bells = [...data.bells.slice(0, 10), ...DEFAULT_BELLS.slice(data.bells.length, 10)]
    .map((value, index) => normalizeTime(value) || DEFAULT_BELLS[index]);
  const cloudGroups = data.groups && typeof data.groups === "object" ? data.groups : {};
  for (const [group, schedule] of Object.entries(cloudGroups)) {
    if (isValidGroupName(group) && schedule && typeof schedule === "object") {
      state.groupSchedules[group] = normalizeSchedule(schedule, state.groupSchedules[group] || emptySchedule());
    }
  }
  if (!cloudGroups["60ТО"] && DAYS.some(day => Array.isArray(data[day]))) {
    state.groupSchedules["60ТО"] = normalizeSchedule(data, state.groupSchedules["60ТО"] || DEFAULT_SCHEDULES);
  }
  for (const group of DEFAULT_GROUPS) {
    state.groupSchedules[group] ||= group === "60ТО" ? cloneSchedule(DEFAULT_SCHEDULES) : emptySchedule();
  }
  state.schedules = cloneSchedule(state.groupSchedules[state.selectedGroup] || emptySchedule());
  persist();
  setCloudStatus("Синхронизировано", "online");
  render();
}

function attachCloudListener(user) {
  cloudUnsubscribe?.();
  cloudUnsubscribe = null;
  currentUser = user;
  if (!currentUser || currentUser.uid !== ADMIN_UID) {
    if (ADMIN_TABS.has(activeTab)) activeTab = "today";
  }
  render();
  const reference = firebaseApi.doc(firestore, "config", "main");
  cloudUnsubscribe = firebaseApi.onSnapshot(reference, snapshot => {
    if (snapshot.exists()) applyCloudSchedule(snapshot.data());
    else setCloudStatus(user.uid === ADMIN_UID ? "Администратор" : "Облако подключено", "online");
  }, error => {
    console.error("Ошибка синхронизации расписания", error);
    setCloudStatus("Ошибка синхронизации", "error");
    const status = document.querySelector("#cloud-settings-status");
    if (status) setSettingsMessage(status, error.message || "Не удалось подключиться к Firestore.", "error");
  });
  setCloudStatus(user.uid === ADMIN_UID ? "Администратор" : "Облако подключено", "online");
}

async function initializeCloud() {
  if (window.SlemeAndroid) {
    setCloudStatus("Подключаем Firebase");
    window.SlemeAndroid.initializeCloud();
    return;
  }
  try {
    const [appSdk, authSdk, firestoreSdk] = await Promise.all([
      import("https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js"),
      import("https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js"),
      import("https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js")
    ]);
    firebaseApi = { ...authSdk, ...firestoreSdk };
    const response = await fetch("../app/google-services.json");
    if (!response.ok) throw new Error(`Не удалось загрузить Firebase-конфигурацию (${response.status}).`);
    const googleServices = await response.json();
    const client = googleServices.client?.find(item => item.client_info?.android_client_info?.package_name === "com.example.phonestarter");
    const apiKey = client?.api_key?.[0]?.current_key;
    const appId = client?.client_info?.mobilesdk_app_id;
    const projectId = googleServices.project_info?.project_id;
    if (!apiKey || !appId || !projectId) throw new Error("В Firebase-конфигурации не найдены параметры основного Android-приложения.");

    const app = appSdk.initializeApp({ apiKey, appId, projectId, authDomain: `${projectId}.firebaseapp.com`, messagingSenderId: googleServices.project_info.project_number });
    auth = authSdk.getAuth(app);
    firestore = firestoreSdk.getFirestore(app);
    authSdk.onAuthStateChanged(auth, async user => {
      if (user) {
        attachCloudListener(user);
      } else {
        try {
          await authSdk.signInAnonymously(auth);
        } catch (error) {
          console.error("Не удалось войти анонимно в Firebase", error);
          setCloudStatus("Firebase недоступен", "error");
        }
      }
    }, error => {
      console.error("Ошибка Firebase Authentication", error);
      setCloudStatus("Ошибка Firebase", "error");
    });
  } catch (error) {
    console.error("Облачная синхронизация не инициализирована", error);
    setCloudStatus(location.protocol === "file:" ? "Нужен локальный сервер" : "Облако недоступно", "error");
  }
}

function setSettingsMessage(node, message, kind = "") {
  node.textContent = message;
  node.classList.toggle("error", kind === "error");
  node.classList.toggle("success", kind === "success");
}

function buildConfig() {
  const sections = [`bells=${state.bells.join("|")}`];
  for (const day of DAYS) sections.push(`${day}=${state.schedules[day].map(value => value || "~").join("|")}`);
  const source = new TextEncoder().encode(sections.join(";"));
  const key = new TextEncoder().encode("SLEME-APP-KEY-2026");
  const encoded = source.map((byte, index) => byte ^ key[index % key.length]);
  let binary = "";
  for (const byte of encoded) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function parseConfig(raw) {
  let binary;
  try {
    binary = atob(raw.trim());
  } catch {
    return null;
  }
  const key = new TextEncoder().encode("SLEME-APP-KEY-2026");
  const bytes = Uint8Array.from(binary, (character, index) => character.charCodeAt(0) ^ key[index % key.length]);
  let decoded;
  try {
    decoded = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    return null;
  }
  const values = new Map(decoded.split(";").filter(section => section.includes("=")).map(section => [section.slice(0, section.indexOf("=")), section.slice(section.indexOf("=") + 1)]));
  if (!values.has("bells") || DAYS.some(day => !values.has(day))) return null;
  const bells = values.get("bells").split("|").map(normalizeTime);
  const schedules = {};
  for (const day of DAYS) schedules[day] = values.get(day).split("|").map(value => value === "~" ? "" : value);
  if (bells.length !== 10 || DAYS.some(day => schedules[day].length !== 10)) return null;
  if (bells.some(value => !value)) return null;
  return { bells, schedules };
}

async function copyConfig() {
  const code = buildConfig();
  const status = document.querySelector("#config-status");
  if (window.SlemeAndroid) {
    window.SlemeAndroid.copyToClipboard(code);
    setSettingsMessage(status, "Строка скопирована. Формат совместим с Android-приложением.", "success");
    return;
  }
  try {
    await navigator.clipboard.writeText(code);
    setSettingsMessage(status, "Строка скопирована. Формат совместим с Android-приложением.", "success");
  } catch (error) {
    console.error("Не удалось скопировать строку в буфер обмена", error);
    document.querySelector("#config-input").value = code;
    document.querySelector("#config-input").focus();
    document.querySelector("#config-input").select();
    setSettingsMessage(status, "Автокопирование недоступно — строка вставлена в поле, скопируйте её вручную.", "error");
  }
}

function importConfig() {
  const input = document.querySelector("#config-input");
  const config = parseConfig(input.value);
  const status = document.querySelector("#config-status");
  if (!config) {
    setSettingsMessage(status, "Строка не распознана. Проверьте, что скопировали её полностью.", "error");
    return;
  }
  state.bells = config.bells;
  state.schedules = config.schedules;
  state.groupSchedules[state.selectedGroup] = cloneSchedule(config.schedules);
  persist();
  setSettingsMessage(status, "Расписание и звонки импортированы.", "success");
  showToast("Расписание и звонки обновлены");
  render();
}

async function loginAdmin() {
  const status = document.querySelector("#cloud-settings-status");
  const email = document.querySelector("#admin-email")?.value.trim();
  const password = document.querySelector("#admin-password")?.value;
  if (!email || !password) {
    setSettingsMessage(status, "Введите email и пароль администратора.", "error");
    return;
  }
  const button = content.querySelector('[data-action="login-admin"]');
  button.disabled = true;
  setSettingsMessage(status, "Выполняется вход…");
  if (window.SlemeAndroid) {
    window.SlemeAndroid.signInAdmin(email, password);
    return;
  }
  try {
    const result = await firebaseApi.signInWithEmailAndPassword(auth, email, password);
    if (result.user.uid !== ADMIN_UID) {
      await firebaseApi.signOut(auth);
      showToast("Этот аккаунт не является администратором");
      return;
    }
    setSettingsMessage(status, "Вход администратора выполнен.", "success");
    render();
  } catch (error) {
    console.error("Ошибка входа администратора", error);
    setSettingsMessage(status, `Не удалось войти: ${error.message}`, "error");
  } finally {
    button.disabled = false;
  }
}

async function publishSchedule() {
  const status = document.querySelector("#cloud-settings-status");
  if (currentUser?.uid !== ADMIN_UID) {
    setSettingsMessage(status, "Для публикации войдите как администратор.", "error");
    return;
  }
  const button = content.querySelector('[data-action="publish"]');
  button.disabled = true;
  setSettingsMessage(status, "Сохраняем расписание в облако…");
  state.groupSchedules[state.selectedGroup] = cloneSchedule(state.schedules);
  const groups = Object.fromEntries(groupNames().map(group => [group, cloneSchedule(state.groupSchedules[group])]));
  const payload = { bells: state.bells, groups };
  for (const day of DAYS) payload[day] = groups["60ТО"][day];
  if (window.SlemeAndroid) {
    window.SlemeAndroid.publishSchedule(JSON.stringify(payload));
    return;
  }
  try {
    await firebaseApi.setDoc(firebaseApi.doc(firestore, "config", "main"), payload);
    setSettingsMessage(status, "Расписание опубликовано для подключённых клиентов.", "success");
    setCloudStatus("Опубликовано", "online");
    showToast("Расписание опубликовано");
  } catch (error) {
    console.error("Не удалось опубликовать расписание", error);
    setSettingsMessage(status, `Ошибка сохранения: ${error.message}`, "error");
    setCloudStatus("Ошибка публикации", "error");
  } finally {
    button.disabled = false;
  }
}

content.addEventListener("click", async event => {
  const dayButton = event.target.closest("[data-day]");
  if (dayButton) {
    if (currentUser?.uid !== ADMIN_UID) return;
    selectedDay = dayButton.dataset.day;
    render();
    return;
  }
  const themeButton = event.target.closest(".theme-button[data-theme]");
  if (themeButton) {
    setTheme(themeButton.dataset.theme);
    render();
    return;
  }
  const actionButton = event.target.closest("[data-action]");
  if (!actionButton) return;
  if (["reset-day", "reset-all", "copy-config", "import-config", "publish"].includes(actionButton.dataset.action)
      && currentUser?.uid !== ADMIN_UID) {
    return;
  }
  switch (actionButton.dataset.action) {
    case "reset-day":
      state.schedules[selectedDay] = state.selectedGroup === "60ТО"
        ? [...DEFAULT_SCHEDULES[selectedDay]]
        : Array(10).fill("");
      persist();
      render();
      showToast(`${DAY_NAMES[selectedDay]} восстановлен`);
      break;
    case "reset-all":
      state.schedules = state.selectedGroup === "60ТО"
        ? cloneSchedule(DEFAULT_SCHEDULES)
        : emptySchedule();
      state.groupSchedules[state.selectedGroup] = cloneSchedule(state.schedules);
      persist();
      render();
      showToast(`Расписание группы ${state.selectedGroup} очищено`);
      break;
    case "copy-config":
      await copyConfig();
      break;
    case "import-config":
      importConfig();
      break;
    case "login-admin":
      await loginAdmin();
      break;
    case "publish":
      await publishSchedule();
      break;
    case "notification-settings":
      if (window.SlemeAndroid) {
        window.SlemeAndroid.openNotificationSettings();
      } else {
        showToast("Push-уведомления доступны в приложении Android");
      }
      break;
    case "logout-admin":
      if (window.SlemeAndroid) {
        window.SlemeAndroid.signOutAdmin();
        return;
      }
      try {
        await firebaseApi.signOut(auth);
        setSettingsMessage(document.querySelector("#cloud-settings-status"), "Вы вышли из аккаунта.");
        render();
      } catch (error) {
        console.error("Не удалось выйти из аккаунта", error);
        setSettingsMessage(document.querySelector("#cloud-settings-status"), `Ошибка выхода: ${error.message}`, "error");
      }
      break;
  }
});

groupSwitcher.addEventListener("click", () => renderGroupPicker());

groupPicker.addEventListener("click", event => {
  const groupButton = event.target.closest("[data-group]");
  if (groupButton) {
    selectGroup(groupButton.dataset.group);
    return;
  }
  if (event.target.closest("[data-group-close]")) closeGroupPicker();
});

groupPicker.addEventListener("submit", event => {
  if (event.target.id !== "add-group-form") return;
  event.preventDefault();
  addGroup(document.querySelector("#new-group-name").value);
});

window.onAndroidCloudState = result => {
  currentUser = result.uid ? { uid: result.uid } : null;
  if (!currentUser || currentUser.uid !== ADMIN_UID) {
    if (ADMIN_TABS.has(activeTab)) activeTab = "today";
  }
  if (result.data) {
    applyCloudSchedule(result.data);
  } else {
    setCloudStatus(
      result.error ? "Ошибка синхронизации" : currentUser?.uid === ADMIN_UID ? "Администратор" : "Облако подключено",
      result.error ? "error" : "online"
    );
    render();
  }
  if (result.error) {
    const status = document.querySelector("#cloud-settings-status");
    if (status) setSettingsMessage(status, result.error, "error");
  }
};

window.onAndroidAdminLogin = (success, message) => {
  const status = document.querySelector("#cloud-settings-status");
  const button = content.querySelector('[data-action="login-admin"]');
  if (button) button.disabled = false;
  if (success) {
    render();
    showToast(message || "Вход администратора выполнен");
  } else if (status) {
    setSettingsMessage(status, message || "Не удалось войти.", "error");
  }
};

window.onAndroidAdminLogout = (success, message) => {
  if (success) {
    activeTab = "today";
    currentUser = null;
    render();
    showToast(message || "Вы вышли из аккаунта администратора");
  } else {
    const status = document.querySelector("#cloud-settings-status");
    if (status) setSettingsMessage(status, message || "Не удалось выйти из аккаунта.", "error");
  }
};

window.onAndroidPublish = (success, message) => {
  const status = document.querySelector("#cloud-settings-status");
  const button = content.querySelector('[data-action="publish"]');
  if (button) button.disabled = false;
  if (status) setSettingsMessage(status, message || (success ? "Расписание опубликовано." : "Ошибка публикации."), success ? "success" : "error");
  if (success) showToast("Расписание опубликовано");
};

content.addEventListener("input", event => {
  const subject = event.target.closest(".subject-input");
  if (subject) {
    if (currentUser?.uid !== ADMIN_UID) return;
    state.schedules[selectedDay][Number(subject.dataset.index)] = subject.value;
    persist();
    return;
  }
  const bell = event.target.closest(".bell-input");
  if (bell && bell.value) {
    if (currentUser?.uid !== ADMIN_UID) return;
    state.bells[Number(bell.dataset.index)] = bell.value;
    persist();
  }
});

content.addEventListener("change", event => {
  const bell = event.target.closest(".bell-input");
  if (!bell || currentUser?.uid !== ADMIN_UID) return;
  const normalized = normalizeTime(bell.value);
  if (!normalized) {
    bell.value = state.bells[Number(bell.dataset.index)] || DEFAULT_BELLS[Number(bell.dataset.index)];
    showToast("Укажите корректное время в формате часы:минуты");
    return;
  }
  state.bells[Number(bell.dataset.index)] = normalized;
  bell.value = normalized;
  persist();
});

document.addEventListener("click", event => {
  const tabButton = event.target.closest("[data-tab]");
  if (!tabButton) return;
  if (ADMIN_TABS.has(tabButton.dataset.tab) && currentUser?.uid !== ADMIN_UID) {
    activeTab = "today";
    render();
    return;
  }
  activeTab = tabButton.dataset.tab;
  render();
});

setTheme(state.theme);
render();
renderGroupPicker();
window.setInterval(() => {
  if (activeTab === "countdown") render();
  if (activeTab === "today") {
    if (weekdayKey(new Date()) !== displayedToday) render();
  }
}, 1000);
initializeCloud();
