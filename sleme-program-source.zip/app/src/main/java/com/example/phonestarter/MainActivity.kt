package com.example.phonestarter

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.Manifest
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.SystemClock
import android.content.pm.PackageManager
import android.provider.Settings
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var scheduleListener: ListenerRegistration? = null
    private var cloudStarted = false
    private val updateExecutor = Executors.newSingleThreadExecutor()
    private val updateCheckInProgress = AtomicBoolean(false)
    private var lastUpdateCheckAt = 0L
    private var offeredUpdateTag: String? = null
    private var activeDownloadId: Long? = null
    private var pendingInstallUri: Uri? = null
    private var downloadReceiverRegistered = false

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val completedId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (completedId != activeDownloadId) return

            val manager = getSystemService(DownloadManager::class.java)
            val query = DownloadManager.Query().setFilterById(completedId)
            manager.query(query).use { cursor ->
                if (!cursor.moveToFirst()) {
                    showUpdateMessage("Не удалось проверить загрузку обновления.")
                    return
                }
                val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                if (statusIndex < 0 || cursor.getInt(statusIndex) != DownloadManager.STATUS_SUCCESSFUL) {
                    val reasonIndex = cursor.getColumnIndex(DownloadManager.COLUMN_REASON)
                    val reason = if (reasonIndex >= 0) cursor.getInt(reasonIndex).toString() else "неизвестная ошибка"
                    showUpdateMessage("Не удалось загрузить обновление ($reason).")
                    return
                }
            }
            val downloadedUri = manager.getUriForDownloadedFile(completedId)
            if (downloadedUri == null) {
                showUpdateMessage("Файл обновления не найден после загрузки.")
                return
            }
            promptInstall(downloadedUri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 13, 25)
        window.navigationBarColor = Color.rgb(9, 13, 25)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(9, 13, 25))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            settings.safeBrowsingEnabled = true
            addJavascriptInterface(AndroidBridge(), "SlemeAndroid")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ) = assetLoader.shouldInterceptRequest(request.url)

                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean = request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN
            }
        }
        setContentView(webView)
        webView.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/index.html")
        createScheduleNotificationChannel()
        subscribeToScheduleUpdates()
        requestNotificationPermissionIfNeeded()
        registerDownloadReceiver()
    }

    override fun onResume() {
        super.onResume()
        checkForUpdates()
        val uri = pendingInstallUri ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && packageManager.canRequestPackageInstalls()) {
            pendingInstallUri = null
            launchInstaller(uri)
        }
    }

    override fun onDestroy() {
        scheduleListener?.remove()
        if (downloadReceiverRegistered) unregisterReceiver(downloadReceiver)
        updateExecutor.shutdownNow()
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("SlemeAndroid")
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun registerDownloadReceiver() {
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(downloadReceiver, filter)
        }
        downloadReceiverRegistered = true
    }

    private fun createScheduleNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = android.app.NotificationChannel(
            SCHEDULE_NOTIFICATION_CHANNEL,
            "Обновления расписания",
            android.app.NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Уведомления об изменениях школьного расписания"
        }
        getSystemService(android.app.NotificationManager::class.java)
            .createNotificationChannel(channel)
    }

    private fun subscribeToScheduleUpdates() {
        FirebaseMessaging.getInstance().subscribeToTopic(SCHEDULE_NOTIFICATION_TOPIC)
            .addOnFailureListener { error ->
                Log.e(TAG, "Не удалось подписать устройство на уведомления расписания", error)
            }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val preferences = getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
        if (preferences.getBoolean(NOTIFICATION_PERMISSION_REQUESTED, false)) return
        preferences.edit().putBoolean(NOTIFICATION_PERMISSION_REQUESTED, true).apply()
        requestPermissions(
            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
            NOTIFICATION_PERMISSION_REQUEST_CODE
        )
    }

    private fun checkForUpdates() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastUpdateCheckAt < UPDATE_CHECK_INTERVAL_MS ||
            !updateCheckInProgress.compareAndSet(false, true)
        ) {
            return
        }
        lastUpdateCheckAt = now

        updateExecutor.execute {
            try {
                val connection = URL(LATEST_RELEASE_URL).openConnection() as HttpURLConnection
                try {
                    connection.requestMethod = "GET"
                    connection.useCaches = false
                    connection.instanceFollowRedirects = true
                    connection.connectTimeout = 7000
                    connection.readTimeout = 10000
                    connection.setRequestProperty("Accept", "application/vnd.github+json")
                    connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
                    connection.setRequestProperty("User-Agent", "sleme-program-android")
                    connection.setRequestProperty("Cache-Control", "no-cache")
                    if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                        throw IllegalStateException("GitHub Releases API вернул HTTP ${connection.responseCode}")
                    }
                    val release = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                    val tag = release.optString("tag_name")
                    val latestVersion = parseVersion(tag)
                        ?: throw IllegalStateException("Неизвестный формат версии релиза: $tag")
                    val installedVersion = packageManager.getPackageInfo(packageName, 0).versionName.orEmpty()
                    val currentVersion = parseVersion(installedVersion)
                        ?: throw IllegalStateException("Неизвестный формат установленной версии: $installedVersion")
                    if (compareVersions(latestVersion, currentVersion) <= 0) return@execute

                    val assets = release.optJSONArray("assets")
                        ?: throw IllegalStateException("В релизе $tag отсутствует APK")
                    var apkUrl: String? = null
                    for (index in 0 until assets.length()) {
                        val asset = assets.optJSONObject(index) ?: continue
                        val name = asset.optString("name")
                        val candidate = asset.optString("browser_download_url")
                        if (name.endsWith(".apk", ignoreCase = true) &&
                            candidate.startsWith("https://github.com/")) {
                            apkUrl = candidate
                            break
                        }
                    }
                    val releaseApkUrl = apkUrl
                        ?: throw IllegalStateException("В релизе $tag не найден APK-файл")

                    runOnUiThread {
                        if (!isFinishing && !isDestroyed && offeredUpdateTag != tag) {
                            offeredUpdateTag = tag
                            offerUpdate(tag, installedVersion, releaseApkUrl)
                        }
                    }
                } finally {
                    connection.disconnect()
                }
            } catch (error: Exception) {
                Log.w(TAG, "Не удалось проверить обновление", error)
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        Toast.makeText(
                            this,
                            "Не удалось проверить обновление. Проверьте подключение к интернету.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } finally {
                updateCheckInProgress.set(false)
            }
        }
    }

    private fun offerUpdate(tag: String, installedVersion: String, apkUrl: String) {
        AlertDialog.Builder(this)
            .setTitle("Доступно обновление")
            .setMessage("Новая версия $tag доступна для загрузки.\nУстановленная версия: $installedVersion.")
            .setNegativeButton("Позже", null)
            .setPositiveButton("Скачать") { _, _ -> downloadUpdate(tag, apkUrl) }
            .show()
    }

    private fun downloadUpdate(tag: String, apkUrl: String) {
        try {
            val request = DownloadManager.Request(Uri.parse(apkUrl))
                .setTitle("sleme program $tag")
                .setDescription("Загрузка обновления приложения")
                .setMimeType(APK_MIME_TYPE)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    "sleme-program-${tag.replace(Regex("[^A-Za-z0-9._-]"), "_")}.apk"
                )
            activeDownloadId = getSystemService(DownloadManager::class.java).enqueue(request)
            showUpdateMessage("Загрузка обновления началась. Вы получите уведомление по её завершении.")
        } catch (error: Exception) {
            Log.e(TAG, "Не удалось начать загрузку обновления", error)
            showUpdateMessage("Не удалось начать загрузку: ${error.localizedMessage ?: "ошибка загрузки"}")
        }
    }

    private fun promptInstall(uri: Uri) {
        pendingInstallUri = uri
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(this)
                .setTitle("Разрешите установку обновления")
                .setMessage("Android попросит разрешить установку приложений, скачанных этим приложением. После разрешения вернитесь сюда.")
                .setNegativeButton("Позже", null)
                .setPositiveButton("Открыть настройки") { _, _ ->
                    val settingsIntent = Intent(
                        android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(settingsIntent)
                }
                .show()
            return
        }
        pendingInstallUri = null
        launchInstaller(uri)
    }

    private fun launchInstaller(uri: Uri) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, APK_MIME_TYPE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (error: Exception) {
            Log.e(TAG, "Не удалось открыть установщик Android", error)
            showUpdateMessage("Не удалось открыть установщик: ${error.localizedMessage ?: "ошибка Android"}")
        }
    }

    private fun showUpdateMessage(message: String) {
        runOnUiThread {
            if (!isFinishing && !isDestroyed) {
                AlertDialog.Builder(this)
                    .setMessage(message)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    private fun parseVersion(value: String): List<Int>? {
        val numericVersion = value.trim().removePrefix("v").substringBefore('-')
        if (numericVersion.isEmpty()) return null
        val parts = numericVersion.split('.')
        if (parts.any { it.isEmpty() || it.any { character -> !character.isDigit() } }) return null
        return parts.map { it.toIntOrNull() ?: return null }
    }

    private fun compareVersions(first: List<Int>, second: List<Int>): Int {
        for (index in 0 until maxOf(first.size, second.size)) {
            val firstPart = first.getOrElse(index) { 0 }
            val secondPart = second.getOrElse(index) { 0 }
            if (firstPart != secondPart) return firstPart.compareTo(secondPart)
        }
        return 0
    }

    private fun postToPage(script: String) {
        runOnUiThread {
            if (::webView.isInitialized && !isFinishing) {
                webView.evaluateJavascript(script, null)
            }
        }
    }

    private fun notifyCloud(userId: String?, data: Map<String, Any>? = null, error: String? = null) {
        val state = JSONObject().apply {
            put("uid", userId ?: JSONObject.NULL)
            put("email", auth.currentUser?.email ?: JSONObject.NULL)
            put("data", data?.let { JSONObject(it) } ?: JSONObject.NULL)
            put("error", error ?: JSONObject.NULL)
        }
        postToPage("window.onAndroidCloudState && window.onAndroidCloudState($state);")
    }

    private fun isOwner(user: FirebaseUser?): Boolean =
        user != null && (
            user.uid == OWNER_UID ||
                user.email?.equals(OWNER_EMAIL, ignoreCase = true) == true
            )

    private fun withScheduleAdminAccess(
        user: FirebaseUser?,
        onAllowed: () -> Unit,
        onDenied: (String) -> Unit
    ) {
        if (isOwner(user)) {
            onAllowed()
            return
        }
        val uid = user?.uid
        if (uid == null) {
            onDenied("Сначала войдите в аккаунт администратора.")
            return
        }
        firestore.collection("config").document("main").get()
            .addOnSuccessListener { snapshot ->
                val adminUids = snapshot.get("adminUids") as? List<*>
                if (adminUids?.contains(uid) == true) {
                    onAllowed()
                } else {
                    onDenied("У этой учётной записи нет прав администратора.")
                }
            }
            .addOnFailureListener { error ->
                onDenied("Не удалось проверить права администратора: ${error.localizedMessage ?: "ошибка Firestore"}")
            }
    }

    private fun startCloudListener() {
        scheduleListener?.remove()
        scheduleListener = null
        val user = auth.currentUser ?: return
        val reference = firestore.collection("config").document("main")
        scheduleListener = reference.addSnapshotListener { snapshot, error ->
            if (error != null) {
                notifyCloud(auth.currentUser?.uid, error = error.localizedMessage ?: "Ошибка Firestore")
                return@addSnapshotListener
            }
            val current = auth.currentUser
            if (snapshot == null || !snapshot.exists()) {
                notifyCloud(current?.uid)
                return@addSnapshotListener
            }
            notifyCloud(current?.uid, snapshot.data)
        }
    }

    private fun ensureSignedIn(onReady: () -> Unit) {
        val user = auth.currentUser
        if (user != null) {
            onReady()
            return
        }
        auth.signInAnonymously()
            .addOnSuccessListener { onReady() }
            .addOnFailureListener { error ->
                notifyCloud(null, error = error.localizedMessage ?: "Не удалось войти в Firebase")
            }
    }

    private fun callPage(function: String, success: Boolean, message: String) {
        val messageJson = JSONObject.quote(message)
        postToPage("window.$function && window.$function($success, $messageJson);")
    }

    private fun callPage(function: String, success: Boolean, vararg values: String) {
        val arguments = values.joinToString(",") { JSONObject.quote(it) }
        postToPage("window.$function && window.$function($success${if (arguments.isEmpty()) "" else ",$arguments"});")
    }

    private inner class AndroidBridge {
        @JavascriptInterface
        fun initializeCloud() {
            runOnUiThread {
                if (cloudStarted) {
                    notifyCloud(auth.currentUser?.uid)
                    return@runOnUiThread
                }
                cloudStarted = true
                ensureSignedIn { startCloudListener() }
            }
        }

        @JavascriptInterface
        fun copyToClipboard(value: String) {
            runOnUiThread {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("sleme_config", value))
                postToPage("window.showToast && window.showToast('Строка скопирована');")
            }
        }

        @JavascriptInterface
        fun openNotificationSettings() {
            runOnUiThread {
                val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                } else {
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                }
                startActivity(intent)
            }
        }

        @JavascriptInterface
        fun signInAdmin(email: String, password: String) {
            runOnUiThread {
                if (email.isBlank() || password.isBlank()) {
                    callPage("onAndroidAdminLogin", false, "Введите email и пароль администратора.")
                    return@runOnUiThread
                }
                auth.signInWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener { result ->
                        withScheduleAdminAccess(
                            result.user,
                            onAllowed = {
                            startCloudListener()
                            notifyCloud(result.user?.uid)
                            callPage("onAndroidAdminLogin", true, "Вход администратора выполнен")
                            },
                            onDenied = { message ->
                            auth.signOut()
                            cloudStarted = false
                            ensureSignedIn {
                                cloudStarted = true
                                startCloudListener()
                                callPage("onAndroidAdminLogin", false, message)
                            }
                            }
                        )
                    }
                    .addOnFailureListener { error ->
                        callPage(
                            "onAndroidAdminLogin",
                            false,
                            "Не удалось войти: ${error.localizedMessage ?: "проверьте email и пароль"}"
                        )
                    }
            }
        }

        @JavascriptInterface
        fun createAdminAccount(email: String, password: String) {
            runOnUiThread {
                if (!isOwner(auth.currentUser)) {
                    callPage("onAndroidAdminCreated", false, "", "", "Только владелец может добавлять администраторов.")
                    return@runOnUiThread
                }
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() || password.length < 6) {
                    callPage("onAndroidAdminCreated", false, "", "", "Введите корректный email и пароль не короче 6 символов.")
                    return@runOnUiThread
                }

                val secondaryApp = try {
                    FirebaseApp.initializeApp(
                        applicationContext,
                        FirebaseApp.getInstance().options,
                        "sleme-admin-${System.currentTimeMillis()}"
                    ) ?: throw IllegalStateException("Не удалось создать временную Firebase-сессию.")
                } catch (error: Exception) {
                    callPage(
                        "onAndroidAdminCreated",
                        false,
                        "",
                        "",
                        "Не удалось подготовить создание аккаунта: ${error.localizedMessage ?: "ошибка Firebase"}"
                    )
                    return@runOnUiThread
                }
                val secondaryAuth = FirebaseAuth.getInstance(secondaryApp)
                fun grantRole(uid: String, actualEmail: String) {
                    firestore.collection("config").document("main")
                        .update("adminUids", FieldValue.arrayUnion(uid))
                        .addOnSuccessListener {
                            secondaryAuth.signOut()
                            secondaryApp.delete()
                            callPage(
                                "onAndroidAdminCreated",
                                true,
                                uid,
                                actualEmail,
                                "Администратор $actualEmail создан и получил доступ."
                            )
                        }
                        .addOnFailureListener { error ->
                            secondaryAuth.signOut()
                            secondaryApp.delete()
                            callPage(
                                "onAndroidAdminCreated",
                                false,
                                uid,
                                actualEmail,
                                "Аккаунт создан, но роль не выдана: ${error.localizedMessage ?: "ошибка Firestore"}. Проверьте правила Firestore и наличие опубликованного расписания."
                            )
                        }
                }

                secondaryAuth.createUserWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener { result ->
                        val user = result.user
                        if (user == null) {
                            secondaryAuth.signOut()
                            secondaryApp.delete()
                            callPage("onAndroidAdminCreated", false, "", "", "Firebase не вернул созданную учётную запись.")
                            return@addOnSuccessListener
                        }
                        grantRole(user.uid, user.email ?: email.trim())
                    }
                    .addOnFailureListener { createError ->
                        if (createError is FirebaseAuthUserCollisionException) {
                            secondaryAuth.signInWithEmailAndPassword(email.trim(), password)
                                .addOnSuccessListener { result ->
                                    val user = result.user
                                    if (user == null) {
                                        secondaryAuth.signOut()
                                        secondaryApp.delete()
                                        callPage("onAndroidAdminCreated", false, "", "", "Firebase не вернул учётную запись.")
                                    } else {
                                        grantRole(user.uid, user.email ?: email.trim())
                                    }
                                }
                                .addOnFailureListener { signInError ->
                                    secondaryAuth.signOut()
                                    secondaryApp.delete()
                                    callPage(
                                        "onAndroidAdminCreated",
                                        false,
                                        "",
                                        "",
                                        "Email уже зарегистрирован; не удалось подтвердить пароль: ${signInError.localizedMessage ?: "ошибка входа"}"
                                    )
                                }
                        } else {
                            secondaryAuth.signOut()
                            secondaryApp.delete()
                            callPage(
                                "onAndroidAdminCreated",
                                false,
                                "",
                                "",
                                "Не удалось создать аккаунт: ${createError.localizedMessage ?: "ошибка Firebase Authentication"}"
                            )
                        }
                    }
            }
        }

        @JavascriptInterface
        fun removeAdminAccount(uid: String) {
            runOnUiThread {
                if (!isOwner(auth.currentUser)) {
                    callPage("onAndroidAdminRemoved", false, uid, "Только владелец может отзывать права администраторов.")
                    return@runOnUiThread
                }
                if (uid.isBlank() || uid == OWNER_UID) {
                    callPage("onAndroidAdminRemoved", false, uid, "Некорректная учётная запись администратора.")
                    return@runOnUiThread
                }

                val docRef = firestore.collection("config").document("main")
                docRef.get()
                    .addOnSuccessListener { snapshot ->
                        val currentAdmins = snapshot.get("adminUids") as? List<*> ?: emptyList<Any>()
                        if (!currentAdmins.contains(uid)) {
                            callPage("onAndroidAdminRemoved", true, uid, "Права администратора уже отозваны.")
                            return@addOnSuccessListener
                        }
                        docRef.update("adminUids", FieldValue.arrayRemove(uid))
                            .addOnSuccessListener {
                                callPage("onAndroidAdminRemoved", true, uid, "Права администратора отозваны. Аккаунт Firebase не удалён.")
                            }
                            .addOnFailureListener { error ->
                                callPage(
                                    "onAndroidAdminRemoved",
                                    false,
                                    uid,
                                    "Не удалось отозвать права: ${error.localizedMessage ?: "ошибка Firestore"}"
                                )
                            }
                    }
                    .addOnFailureListener { error ->
                        callPage(
                            "onAndroidAdminRemoved",
                            false,
                            uid,
                            "Не удалось проверить список администраторов: ${error.localizedMessage ?: "ошибка Firestore"}"
                        )
                    }
            }
        }

        @JavascriptInterface
        fun signOutAdmin() {
            runOnUiThread {
                scheduleListener?.remove()
                scheduleListener = null
                cloudStarted = false
                auth.signOut()
                notifyCloud(null)
                ensureSignedIn {
                    cloudStarted = true
                    startCloudListener()
                    callPage("onAndroidAdminLogout", true, "Вы вышли из аккаунта администратора")
                }
            }
        }

        @JavascriptInterface
        fun publishSchedule(payloadJson: String) {
            runOnUiThread {
                withScheduleAdminAccess(
                    auth.currentUser,
                    onAllowed = {
                        val payload = try {
                            JSONObject(payloadJson).toFirestoreData()
                        } catch (error: Exception) {
                            callPage("onAndroidPublish", false, "Не удалось прочитать расписание: ${error.localizedMessage}")
                            return@withScheduleAdminAccess
                        }
                        firestore.collection("config").document("main")
                            .set(payload)
                            .addOnSuccessListener {
                                callPage("onAndroidPublish", true, "Расписание опубликовано для подключённых клиентов.")
                            }
                            .addOnFailureListener { error ->
                                callPage(
                                    "onAndroidPublish",
                                    false,
                                    "Ошибка сохранения: ${error.localizedMessage ?: "ошибка Firestore"}"
                                )
                            }
                    },
                    onDenied = { message -> callPage("onAndroidPublish", false, message) }
                )
            }
        }
    }

    private fun JSONObject.toFirestoreData(): Map<String, Any> {
        val result = mutableMapOf<String, Any>()
        val keys = keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = opt(key)
            when (value) {
                is org.json.JSONArray -> result[key] = value.toFirestoreList()
                is JSONObject -> result[key] = value.toFirestoreData()
                is String, is Number, is Boolean -> result[key] = value
            }
        }
        return result
    }

    private fun org.json.JSONArray.toFirestoreList(): List<Any> =
        (0 until length()).mapNotNull { index ->
            when (val value = opt(index)) {
                is org.json.JSONArray -> value.toFirestoreList()
                is JSONObject -> value.toFirestoreData()
                is String, is Number, is Boolean -> value
                else -> null
            }
        }

    companion object {
        private const val TAG = "MainActivity"
        private const val SCHEDULE_NOTIFICATION_TOPIC = "schedule_updates"
        private const val SCHEDULE_NOTIFICATION_CHANNEL = "schedule_updates"
        private const val PREFERENCES_NAME = "sleme_notifications"
        private const val NOTIFICATION_PERMISSION_REQUESTED = "permission_requested"
        private const val NOTIFICATION_PERMISSION_REQUEST_CODE = 4101
        private const val UPDATE_CHECK_INTERVAL_MS = 60_000L
        private const val LATEST_RELEASE_URL =
            "https://api.github.com/repos/sleme228/sleme-program/releases/latest"
        private const val APK_MIME_TYPE = "application/vnd.android.package-archive"
        private const val ADMIN_UID = "3hZ5bKEPYmSQ4TaH783ZJGiNyTv2"
        private const val OWNER_UID = "3hZ5bKEPYmSQ4TaH783ZJGiNyTv2"
        private const val OWNER_EMAIL = "anonimysskamer@gmail.com"
    }
}
