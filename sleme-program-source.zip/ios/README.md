# iPhone build for sleme program

This folder contains the SwiftUI iOS client source. The Android project at the repository root is unchanged. iOS compilation/signing requires macOS and Xcode.

## Xcode setup

1. On a Mac, install Xcode from the Mac App Store and open it once to install components.
2. In Xcode, choose **File → New → Project → iOS → App**.
3. Product Name: `SlemeProgram`; Interface: **SwiftUI**; Language: **Swift**; Bundle Identifier: `com.example.slemeprogram.ios` (or another unique ID you register in Firebase).
4. Add the Swift files from this folder to the Xcode app target: `SlemeProgramApp.swift`, `ContentView.swift`, `ScheduleStore.swift`.
5. In Xcode choose **File → Add Package Dependencies** and add `https://github.com/firebase/firebase-ios-sdk`.
6. Select products **FirebaseAuth**, **FirebaseFirestore**, and **FirebaseMessaging** for the app target.
7. In Firebase Console, open the existing Android timetable project `sleme-program`, choose **Add app → iOS**, register the same Bundle Identifier, download `GoogleService-Info.plist`, and add it to the Xcode project with **Copy items if needed** enabled.
8. In Firebase Authentication, enable **Anonymous** and **Email/Password**. The iOS app uses anonymous sign-in for reading and the existing administrator account for publishing.
9. Confirm the Firestore rules allow authenticated reads of `config/main` and writes only for the administrator UID `3hZ5bKEPYmSQ4TaH783ZJGiNyTv2`.
10. Select an iPhone simulator and press Run. To install on a real iPhone, connect it to the Mac, select the device, set a development Team under **Signing & Capabilities**, and press Run.

## Push notifications

The iOS source subscribes devices to the Firebase topic `schedule_updates` and asks for notification permission. To receive schedule announcements:

1. Use a real iPhone and an Apple Developer team; APNs delivery is not available on the simulator.
2. In Xcode **Signing & Capabilities**, add **Push Notifications** to the app target.
3. In the Apple Developer account, create an APNs authentication key and upload its `.p8` key, Key ID, and Team ID in Firebase Console → Project settings → Cloud Messaging for the iOS app.
4. Build and install the updated app, then allow notifications when prompted.
5. Deploy the root Firebase Cloud Function by following the push-notification setup in the main project `README.md`.

The Firebase Cloud Function sends a notification to the shared topic after a schedule or bell-time change is published. The web preview does not receive push notifications.

## Install/share with iPhone

- For your own connected iPhone: run from Xcode with a free Apple ID team. The development-signed app is for testing and may need to be reinstalled/re-signed after its provisioning expires.
- For other testers: use TestFlight. An Apple Developer Program membership is required; archive in Xcode, upload to App Store Connect, add testers, and install through Apple's TestFlight app.
- For public release: submit the archive to App Store review through App Store Connect.

## Important

The Firebase JSON file is Android-only and cannot be used by iOS. iOS needs its own `GoogleService-Info.plist`, registered under the same Firebase project. Never put passwords or private server credentials in the app.
