SwiftUI source files for the iOS companion app. Follow `../README.md` to create the Xcode target, add Firebase packages, register the iOS app in Firebase, and install it on an iPhone.
