import Foundation
import Combine
import FirebaseAuth
import FirebaseFirestore

@MainActor
final class ScheduleStore: ObservableObject {
    static let days = ["monday", "tuesday", "wednesday", "thursday", "friday"]
    static let dayNames = ["monday": "Понедельник", "tuesday": "Вторник", "wednesday": "Среда", "thursday": "Четверг", "friday": "Пятница"]
    static let dayShortNames = ["monday": "ПН", "tuesday": "ВТ", "wednesday": "СР", "thursday": "ЧТ", "friday": "ПТ"]
    static let adminUID = "3hZ5bKEPYmSQ4TaH783ZJGiNyTv2"

    @Published var bells: [String] = ["08:30", "09:20", "10:20", "11:20", "12:10", "13:00", "13:50", "14:40", "15:20", "16:10"]
    @Published var schedules: [String: [String]] = [
        "monday": ["Русский", "Математика", "История", "Физика", "Литература", "Химия", "География", "Иностранный", "Технология", "Физкультура"],
        "tuesday": ["Математика", "Русский", "Биология", "Обществознание", "Информатика", "География", "Музыка", "ОБЖ", "Труд", "Физкультура"],
        "wednesday": ["Алгебра", "Литература", "Химия", "История", "Физика", "Русский", "География", "Черчение", "Биология", "Физкультура"],
        "thursday": ["Математика", "Русский", "Английский", "Информатика", "Физика", "География", "История", "Химия", "ОБЖ", "Физкультура"],
        "friday": ["Русский", "Алгебра", "География", "Литература", "История", "Английский", "Физкультура", "Музыка", "Технология", "Гимнастика"]
    ]
    @Published var status = "Загружаем расписание…"
    @Published var currentUser: User?

    private let auth = Auth.auth()
    private let document = Firestore.firestore().collection("config").document("main")
    private var listener: ListenerRegistration?

    var isAdmin: Bool { currentUser?.uid == Self.adminUID }

    init() {
        loadLocal()
        currentUser = auth.currentUser
        if auth.currentUser == nil {
            auth.signInAnonymously { [weak self] result, error in
                Task { @MainActor in
                    guard let self else { return }
                    if let error {
                        self.status = "Нет связи с Firebase: \(error.localizedDescription)"
                    } else {
                        self.currentUser = result?.user
                        self.listenForCloud()
                    }
                }
            }
        } else {
            listenForCloud()
        }
    }

    deinit { listener?.remove() }

    func listenForCloud() {
        listener?.remove()
        listener = document.addSnapshotListener { [weak self] snapshot, error in
            Task { @MainActor in
                guard let self else { return }
                if let error {
                    self.status = "Ошибка облака: \(error.localizedDescription)"
                    return
                }
                guard let data = snapshot?.data(), let bells = data["bells"] as? [String] else {
                    self.status = "Показываем сохранённое расписание"
                    return
                }
                self.bells = bells
                for day in Self.days {
                    if let subjects = data[day] as? [String] {
                        self.schedules[day] = subjects
                    }
                }
                self.status = "Синхронизировано с облаком"
                self.saveLocal()
            }
        }
    }

    func updateSubject(day: String, index: Int, value: String) {
        guard var list = schedules[day], list.indices.contains(index) else { return }
        list[index] = value
        schedules[day] = list
        saveLocal()
    }

    func updateBell(index: Int, value: String) {
        guard bells.indices.contains(index) else { return }
        bells[index] = value
        saveLocal()
    }

    func signInAdmin(email: String, password: String, completion: @escaping (String) -> Void) {
        auth.signIn(withEmail: email, password: password) { [weak self] result, error in
            Task { @MainActor in
                guard let self else { return }
                if let error {
                    completion("Не удалось войти: \(error.localizedDescription)")
                    return
                }
                guard let user = result?.user, user.uid == Self.adminUID else {
                    try? self.auth.signOut()
                    completion("Этот аккаунт не является администратором")
                    return
                }
                self.currentUser = user
                completion("Вход администратора выполнен")
            }
        }
    }

    func signOutAdmin() {
        try? auth.signOut()
        auth.signInAnonymously { [weak self] result, _ in
            Task { @MainActor in
                self?.currentUser = result?.user
                self?.listenForCloud()
            }
        }
    }

    func publish(completion: @escaping (String) -> Void) {
        guard isAdmin else {
            completion("Сначала войдите как администратор")
            return
        }
        var data: [String: Any] = ["bells": bells]
        for day in Self.days { data[day] = schedules[day] ?? [] }
        document.setData(data) { error in
            DispatchQueue.main.async {
                completion(error.map { "Ошибка сохранения: \($0.localizedDescription)" } ?? "Расписание опубликовано")
            }
        }
    }

    private func saveLocal() {
        UserDefaults.standard.set(bells, forKey: "sleme.bells")
        UserDefaults.standard.set(schedules, forKey: "sleme.schedules")
    }

    private func loadLocal() {
        if let savedBells = UserDefaults.standard.stringArray(forKey: "sleme.bells") { bells = savedBells }
        if let savedSchedules = UserDefaults.standard.dictionary(forKey: "sleme.schedules") as? [String: [String]] { schedules = savedSchedules }
    }
}
