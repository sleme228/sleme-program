import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: ScheduleStore
    @State private var selectedTab = 0
    @State private var selectedDay = "monday"

    private let tabs = [("Сегодня", "sun.max.fill"), ("До урока", "timer"), ("Расписание", "calendar"), ("Звонки", "bell.fill"), ("Настройки", "gearshape.fill")]

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.035, green: 0.055, blue: 0.12), Color(red: 0.10, green: 0.07, blue: 0.24)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(spacing: 0) {
                Text("sleme program")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.top, 8)
                Text(store.status)
                    .font(.caption)
                    .foregroundStyle(.cyan.opacity(0.85))
                    .lineLimit(1)
                    .padding(.top, 4)
                Group {
                    switch selectedTab {
                    case 0: todayView
                    case 1: countdownView
                    case 2: scheduleView
                    case 3: bellsView
                    default: settingsView
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                tabBar
            }
            .padding(.horizontal, 18)
        }
        .preferredColorScheme(.dark)
    }

    private var todayView: some View {
        let key = todayKey
        return ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                sectionHeading("Сегодня", subtitle: Date.now.formatted(date: .complete, time: .omitted))
                ForEach(0..<10, id: \.self) { index in
                    lessonRow(number: index + 1, subject: store.schedules[key]?[safe: index] ?? "—", time: store.bells[safe: index] ?? "—")
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
            .padding(.top, 22)
        }
    }

    private var countdownView: some View {
        TimelineView(.periodic(from: .now, by: 1)) { context in
            let next = nextLesson(after: context.date)
            VStack(spacing: 20) {
                sectionHeading("До следующего урока", subtitle: next?.name ?? "Занятий больше нет")
                VStack(spacing: 12) {
                    Image(systemName: "hourglass")
                        .font(.system(size: 30, weight: .medium))
                        .foregroundStyle(Color.cyan)
                    Text(next.map { countdownText(to: $0.date, now: context.date) } ?? "—")
                        .font(.system(size: 42, weight: .bold, design: .rounded).monospacedDigit())
                        .foregroundStyle(.white)
                    Text(next.map { "Начало в \($0.time)" } ?? "")
                        .font(.subheadline)
                        .foregroundStyle(Color.cyan.opacity(0.85))
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 44)
                .background(cardBackground)
                Spacer()
            }
            .padding(.top, 22)
        }
    }

    private var scheduleView: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                sectionHeading("Расписание", subtitle: "Изменения сохраняются на этом устройстве")
                HStack(spacing: 7) {
                    ForEach(ScheduleStore.days, id: \.self) { day in
                        Button { withAnimation(.spring(response: 0.32)) { selectedDay = day } } label: {
                            Text(ScheduleStore.dayShortNames[day] ?? day)
                                .font(.caption.bold())
                                .frame(maxWidth: .infinity, minHeight: 42)
                                .background(selectedDay == day ? Color.purple : Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                        }
                        .buttonStyle(.plain)
                    }
                }
                ForEach(0..<10, id: \.self) { index in
                    HStack(spacing: 12) {
                        Text(String(format: "%02d", index + 1)).font(.system(.callout, design: .rounded).bold()).foregroundStyle(Color.cyan).frame(width: 34)
                        TextField("Название урока", text: Binding(
                            get: { store.schedules[selectedDay]?[safe: index] ?? "" },
                            set: { store.updateSubject(day: selectedDay, index: index, value: $0) }
                        ))
                        .textFieldStyle(.plain)
                    }
                    .padding(15)
                    .background(cardBackground)
                }
            }
            .padding(.top, 22)
        }
    }

    private var bellsView: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                sectionHeading("Время звонков", subtitle: "Задай время начала каждого урока")
                ForEach(0..<store.bells.count, id: \.self) { index in
                    HStack {
                        Text("Урок \(index + 1)").foregroundStyle(.white)
                        Spacer()
                        TextField("08:30", text: Binding(
                            get: { store.bells[safe: index] ?? "" },
                            set: { store.updateBell(index: index, value: $0) }
                        ))
                        .multilineTextAlignment(.trailing)
                        .keyboardType(.numbersAndPunctuation)
                        .foregroundStyle(Color.cyan)
                        .frame(width: 84)
                    }
                    .padding(15)
                    .background(cardBackground)
                }
            }
            .padding(.top, 22)
        }
    }

    private var settingsView: some View {
        AdminSettingsView()
            .environmentObject(store)
    }

    private var tabBar: some View {
        HStack(spacing: 0) {
            ForEach(tabs.indices, id: \.self) { index in
                Button {
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.82)) { selectedTab = index }
                } label: {
                    VStack(spacing: 5) {
                        Image(systemName: tabs[index].1).font(.system(size: 16, weight: .semibold))
                        Text(tabs[index].0).font(.system(size: 9, weight: .semibold))
                    }
                    .foregroundStyle(selectedTab == index ? Color.white : Color.white.opacity(0.55))
                    .frame(maxWidth: .infinity, minHeight: 58)
                    .background(selectedTab == index ? Color.purple.opacity(0.55) : .clear, in: RoundedRectangle(cornerRadius: 16))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(6)
        .background(Color.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 22))
        .padding(.vertical, 8)
    }

    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(LinearGradient(colors: [Color.white.opacity(0.10), Color.white.opacity(0.045)], startPoint: .topLeading, endPoint: .bottomTrailing))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.11), lineWidth: 1))
    }

    private var todayKey: String {
        let weekday = Calendar.current.component(.weekday, from: .now)
        let mapping = [2: "monday", 3: "tuesday", 4: "wednesday", 5: "thursday", 6: "friday"]
        return mapping[weekday] ?? "monday"
    }

    private func sectionHeading(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.system(size: 25, weight: .bold, design: .rounded)).foregroundStyle(.white)
            Text(subtitle).font(.subheadline).foregroundStyle(Color.white.opacity(0.58))
        }
        .padding(.bottom, 3)
    }

    private func lessonRow(number: Int, subject: String, time: String) -> some View {
        HStack(spacing: 14) {
            Text(String(format: "%02d", number)).font(.system(.callout, design: .rounded).bold()).foregroundStyle(Color.cyan).frame(width: 34)
            Text(subject).font(.system(size: 16, weight: .semibold, design: .rounded)).foregroundStyle(.white)
            Spacer(minLength: 8)
            Text(time).font(.system(.callout, design: .rounded).medium()).foregroundStyle(Color.cyan)
        }
        .padding(16)
        .background(cardBackground)
    }

    private func nextLesson(after date: Date) -> (name: String, time: String, date: Date)? {
        let key = todayKey
        for index in store.bells.indices {
            let parts = store.bells[index].split(separator: ":").compactMap { Int($0) }
            guard parts.count == 2 else { continue }
            var components = Calendar.current.dateComponents([.year, .month, .day], from: date)
            components.hour = parts[0]
            components.minute = parts[1]
            guard let lessonDate = Calendar.current.date(from: components), lessonDate > date else { continue }
            return (store.schedules[key]?[safe: index] ?? "Урок \(index + 1)", store.bells[index], lessonDate)
        }
        return nil
    }

    private func countdownText(to target: Date, now: Date) -> String {
        let seconds = max(0, Int(target.timeIntervalSince(now)))
        return String(format: "%02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60)
    }
}

private struct AdminSettingsView: View {
    @EnvironmentObject private var store: ScheduleStore
    @State private var email = ""
    @State private var password = ""
    @State private var message = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("Настройки").font(.system(size: 25, weight: .bold, design: .rounded)).foregroundStyle(.white)
                Text("Облачная синхронизация расписания").font(.subheadline).foregroundStyle(.white.opacity(0.6))
                VStack(alignment: .leading, spacing: 12) {
                    Text(store.isAdmin ? "Администратор вошёл" : "Вход администратора")
                        .font(.headline).foregroundStyle(Color.cyan)
                    if !store.isAdmin {
                        TextField("Email", text: $email).textInputAutocapitalization(.never).keyboardType(.emailAddress).textFieldStyle(.roundedBorder)
                        SecureField("Пароль", text: $password).textFieldStyle(.roundedBorder)
                        Button("Войти") {
                            store.signInAdmin(email: email, password: password) { message = $0 }
                        }
                        .buttonStyle(PremiumButtonStyle(primary: true))
                    } else {
                        Button("Выйти из аккаунта администратора") { store.signOutAdmin() }
                            .buttonStyle(PremiumButtonStyle(primary: false))
                    }
                    Button("Опубликовать расписание и звонки") {
                        store.publish { message = $0 }
                    }
                    .buttonStyle(PremiumButtonStyle(primary: true))
                    if !message.isEmpty {
                        Text(message).font(.caption).foregroundStyle(.white.opacity(0.72))
                    }
                }
                .padding(18)
                .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.08)).overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.12))))
            }
            .padding(.top, 22)
        }
    }
}

private struct PremiumButtonStyle: ButtonStyle {
    let primary: Bool
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .bold, design: .rounded))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity, minHeight: 48)
            .background(primary ? Color.purple : Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 15))
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
            .animation(.easeOut(duration: 0.15), value: configuration.isPressed)
    }
}

private extension Collection {
    subscript(safe index: Index) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
