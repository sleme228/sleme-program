const FIREBASE_PROJECT_ID = "sleme-program";
const FIRESTORE_DOCUMENT_PATH = "config/main";
const NOTIFICATION_TOPIC = "schedule_updates";
const FINGERPRINT_PROPERTY = "schedule_fingerprint";
const TRIGGER_HANDLER = "checkScheduleAndNotify";

function setupScheduleNotifications() {
  const properties = PropertiesService.getScriptProperties();
  const document = getScheduleDocument();
  if (!document) {
    throw new Error(`Firestore document ${FIRESTORE_DOCUMENT_PATH} does not exist.`);
  }

  if (!properties.getProperty(FINGERPRINT_PROPERTY)) {
    properties.setProperty(FINGERPRINT_PROPERTY, fingerprint(document.fields || {}));
  }

  const hasTrigger = ScriptApp.getProjectTriggers()
    .some(trigger => trigger.getHandlerFunction() === TRIGGER_HANDLER);
  if (!hasTrigger) {
    ScriptApp.newTrigger(TRIGGER_HANDLER).timeBased().everyMinutes(1).create();
  }
  console.log("Schedule notification polling is configured.");
}

function checkScheduleAndNotify() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(1000)) return;

  try {
    const document = getScheduleDocument();
    if (!document) return;

    const fields = document.fields || {};
    const currentFingerprint = fingerprint(fields);
    const properties = PropertiesService.getScriptProperties();
    const previousFingerprint = properties.getProperty(FINGERPRINT_PROPERTY);
    if (!previousFingerprint) {
      properties.setProperty(FINGERPRINT_PROPERTY, currentFingerprint);
      return;
    }
    if (currentFingerprint === previousFingerprint) return;

    sendScheduleNotification();
    properties.setProperty(FINGERPRINT_PROPERTY, currentFingerprint);
    console.log("Schedule update notification sent.");
  } finally {
    lock.releaseLock();
  }
}

function getScheduleDocument() {
  const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/${FIRESTORE_DOCUMENT_PATH}`;
  const response = UrlFetchApp.fetch(url, {
    headers: { Authorization: `Bearer ${ScriptApp.getOAuthToken()}` },
    muteHttpExceptions: true,
  });
  const status = response.getResponseCode();
  if (status === 404) return null;
  if (status < 200 || status >= 300) {
    throw new Error(`Firestore read failed (HTTP ${status}): ${response.getContentText()}`);
  }
  return JSON.parse(response.getContentText());
}

function fingerprint(fields) {
  const schedule = {};
  for (const key of ["bells", "groups", "monday", "tuesday", "wednesday", "thursday", "friday"]) {
    if (Object.prototype.hasOwnProperty.call(fields, key)) schedule[key] = fields[key];
  }
  const bytes = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    stableStringify(schedule),
    Utilities.Charset.UTF_8,
  );
  return Utilities.base64EncodeWebSafe(bytes);
}

function stableStringify(value) {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value).sort().map(key =>
      `${JSON.stringify(key)}:${stableStringify(value[key])}`,
    ).join(",")}}`;
  }
  return JSON.stringify(value);
}

function sendScheduleNotification() {
  const url = `https://fcm.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/messages:send`;
  const response = UrlFetchApp.fetch(url, {
    method: "post",
    contentType: "application/json",
    headers: { Authorization: `Bearer ${ScriptApp.getOAuthToken()}` },
    payload: JSON.stringify({
      message: {
        topic: NOTIFICATION_TOPIC,
        notification: {
          title: "Расписание обновлено",
          body: "Откройте приложение и выберите свою группу, чтобы посмотреть изменения.",
        },
        data: { type: "schedule_update" },
        android: {
          priority: "HIGH",
          notification: { channel_id: NOTIFICATION_TOPIC, sound: "default" },
        },
        apns: { payload: { aps: { sound: "default" } } },
      },
    }),
    muteHttpExceptions: true,
  });
  const status = response.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error(`FCM send failed (HTTP ${status}): ${response.getContentText()}`);
  }
}
