const { initializeApp } = require("firebase-admin/app");
const { getMessaging } = require("firebase-admin/messaging");
const { logger } = require("firebase-functions");
const { onDocumentWritten } = require("firebase-functions/v2/firestore");

initializeApp();

const TOPIC = "schedule_updates";
const REGION = "europe-west1";
const SCHEDULE_FIELDS = [
  "bells",
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
];

function scheduleSnapshot(data) {
  return Object.fromEntries(
    SCHEDULE_FIELDS.map((field) => [
      field,
      Array.isArray(data[field]) ? data[field] : [],
    ]),
  );
}

function containsSchedule(data) {
  return SCHEDULE_FIELDS.some((field) => Array.isArray(data[field]));
}

exports.scheduleUpdated = onDocumentWritten(
  { document: "config/main", region: REGION },
  async (event) => {
    const before = event.data?.before;
    const after = event.data?.after;
    if (!after?.exists) return;

    const currentSchedule = after.data();
    if (!containsSchedule(currentSchedule)) {
      logger.warn("Schedule document does not contain schedule fields", {
        eventId: event.id,
      });
      return;
    }

    const previousSchedule = before?.exists ? before.data() : null;
    if (
      previousSchedule &&
      JSON.stringify(scheduleSnapshot(previousSchedule)) ===
        JSON.stringify(scheduleSnapshot(currentSchedule))
    ) {
      return;
    }

    const messageId = await getMessaging().send({
      topic: TOPIC,
      notification: {
        title: "Расписание обновлено",
        body: "Откройте приложение, чтобы посмотреть изменения.",
      },
      data: { type: "schedule_update" },
      android: {
        priority: "high",
        notification: { channelId: TOPIC, sound: "default" },
      },
      apns: { payload: { aps: { sound: "default" } } },
    });

    logger.info("Schedule update notification sent", {
      eventId: event.id,
      messageId,
    });
  },
);
