const { initializeApp } = require("firebase-admin/app");
const { getMessaging } = require("firebase-admin/messaging");
const { logger } = require("firebase-functions");
const { onDocumentWritten } = require("firebase-functions/v2/firestore");

initializeApp();

const TOPIC = "schedule_updates";
const REGION = "europe-west1";
const SCHEDULE_FIELDS = [
  "bells",
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
];

function scheduleSnapshot(data) {
  const snapshot = Object.fromEntries(
    SCHEDULE_FIELDS.filter((field) => field !== "bells").map((field) => [
      field,
      Array.isArray(data[field]) ? data[field] : [],
    ]),
  );
  snapshot.bells = Array.isArray(data.bells) ? data.bells : [];
  if (data.groups && typeof data.groups === "object") snapshot.groups = data.groups;
  return snapshot;
}

function containsSchedule(data) {
  return Array.isArray(data.bells) &&
    (data.groups && typeof data.groups === "object" ||
      SCHEDULE_FIELDS.some((field) => field !== "bells" && Array.isArray(data[field])));
}

exports.scheduleUpdated = onDocumentWritten(
  { document: "config/main", region: REGION },
  async (event) => {
    const before = event.data?.before;
    const after = event.data?.after;
    if (!after?.exists) return;

    const currentSchedule = after.data();
    if (!containsSchedule(currentSchedule)) {
      logger.warn("Schedule document does not contain schedule fields", {
        eventId: event.id,
      });
      return;
    }

    const previousSchedule = before?.exists ? before.data() : null;
    if (
      previousSchedule &&
      JSON.stringify(scheduleSnapshot(previousSchedule)) ===
        JSON.stringify(scheduleSnapshot(currentSchedule))
    ) {
      return;
    }

    const messageId = await getMessaging().send({
      topic: TOPIC,
      notification: {
        title: "Расписание обновлено",
        body: "Откройте приложение и выберите свою группу, чтобы посмотреть изменения.",
      },
      data: { type: "schedule_update" },
      android: {
        priority: "high",
        notification: { channelId: TOPIC, sound: "default" },
      },
      apns: { payload: { aps: { sound: "default" } } },
    });

    logger.info("Schedule update notification sent", {
      eventId: event.id,
      messageId,
    });
  },
);
